#!/usr/bin/env python
"""Script to fix session issues specifically for chat functionality."""
import os
import django
import sys

# Set up Django environment
os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'festival_project.settings')
django.setup()

from django.contrib.sessions.models import Session
from django.utils import timezone
import json

def main():
    """Clean up problematic sessions and print diagnostic information."""
    print("\n=== Chat Session Repair Tool ===\n")
    
    # Get all active sessions
    sessions = Session.objects.filter(expire_date__gte=timezone.now())
    print(f"Found {sessions.count()} active sessions")
    
    problematic_sessions = 0
    repaired_sessions = 0
    deleted_sessions = 0
    
    for session in sessions:
        try:
            # Try to decode the session data
            data = session.get_decoded()
            print(f"Session: {session.session_key[:10]}... expires: {session.expire_date}")
            
            # Check if this is a problematic session
            if not data.get('_auth_user_id'):
                print(f"  - No authenticated user, skipping")
                continue
                
        except Exception as e:
            print(f"  - ERROR: Could not decode session {session.session_key[:10]}...: {e}")
            problematic_sessions += 1
            
            # Delete corrupted sessions
            session.delete()
            deleted_sessions += 1
            print(f"  - Deleted corrupted session")
            continue
    
    # Print summary
    print("\n=== Summary ===")
    print(f"Total active sessions: {sessions.count()}")
    print(f"Problematic sessions: {problematic_sessions}")
    print(f"Repaired sessions: {repaired_sessions}")
    print(f"Deleted sessions: {deleted_sessions}")
    
    # Provide next steps
    print("\n=== Next Steps ===")
    print("1. Make sure your SECRET_KEY is not changing between server restarts")
    print("2. Clear your browser cookies for the site")
    print("3. Restart your Django server")
    print("4. Log in again to create a fresh session")

if __name__ == "__main__":
    main()
