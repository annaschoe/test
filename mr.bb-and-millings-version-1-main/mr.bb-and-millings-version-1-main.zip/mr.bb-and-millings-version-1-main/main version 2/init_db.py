#!/usr/bin/env python
"""
Database initialization script for the modular app structure.
This script directly creates the necessary tables and sets up initial data.
"""
import os
import sqlite3
import sys
from pathlib import Path
from datetime import datetime
import hashlib

# Get the project root directory
BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / 'db.sqlite3'

def create_tables():
    """Create necessary database tables for all apps."""
    print("Creating database tables...")
    
    # Define SQL statements for table creation
    sql_statements = [
        # Auth-related tables
        """
        CREATE TABLE IF NOT EXISTS django_migrations (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            app VARCHAR(255) NOT NULL,
            name VARCHAR(255) NOT NULL,
            applied DATETIME NOT NULL
        );
        """,
        
        # Users app tables
        """
        CREATE TABLE IF NOT EXISTS users_app_user (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            password VARCHAR(128) NOT NULL,
            last_login DATETIME NULL,
            is_superuser BOOLEAN NOT NULL,
            username VARCHAR(150) UNIQUE NOT NULL,
            first_name VARCHAR(150) NOT NULL,
            last_name VARCHAR(150) NOT NULL,
            email VARCHAR(254) NOT NULL,
            is_staff BOOLEAN NOT NULL,
            is_active BOOLEAN NOT NULL,
            date_joined DATETIME NOT NULL,
            location_name VARCHAR(255) NOT NULL,
            last_activity DATETIME NOT NULL,
            phone_number VARCHAR(20) NOT NULL,
            is_location_manager BOOLEAN NOT NULL,
            notes TEXT NOT NULL
        );
        """,
        
        """
        CREATE TABLE IF NOT EXISTS users_app_user_groups (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            group_id INTEGER NOT NULL,
            UNIQUE (user_id, group_id),
            FOREIGN KEY (user_id) REFERENCES users_app_user (id) ON DELETE CASCADE,
            FOREIGN KEY (group_id) REFERENCES auth_group (id) ON DELETE CASCADE
        );
        """,
        
        """
        CREATE TABLE IF NOT EXISTS users_app_user_user_permissions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            permission_id INTEGER NOT NULL,
            UNIQUE (user_id, permission_id),
            FOREIGN KEY (user_id) REFERENCES users_app_user (id) ON DELETE CASCADE,
            FOREIGN KEY (permission_id) REFERENCES auth_permission (id) ON DELETE CASCADE
        );
        """,
        
        # Inventory app tables
        """
        CREATE TABLE IF NOT EXISTS inventory_app_inventory (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name VARCHAR(255) NOT NULL,
            quantity INTEGER NOT NULL,
            type VARCHAR(50) NOT NULL,
            timestamp DATETIME NOT NULL,
            location_id INTEGER NOT NULL,
            FOREIGN KEY (location_id) REFERENCES users_app_user (id) ON DELETE CASCADE
        );
        """,
        
        """
        CREATE TABLE IF NOT EXISTS inventory_app_inventorychange (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            item_name VARCHAR(255) NOT NULL,
            action VARCHAR(50) NOT NULL,
            quantity_before INTEGER NULL,
            quantity_after INTEGER NULL,
            location_name VARCHAR(255) NOT NULL,
            timestamp DATETIME NOT NULL,
            performed_by_id INTEGER NULL,
            notes TEXT NOT NULL,
            FOREIGN KEY (performed_by_id) REFERENCES users_app_user (id) ON DELETE SET NULL
        );
        """,
        
        # Transfers app tables
        """
        CREATE TABLE IF NOT EXISTS transfers_app_transfer (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            item VARCHAR(255) NOT NULL,
            from_location VARCHAR(255) NOT NULL,
            to_location VARCHAR(255) NOT NULL,
            quantity INTEGER NOT NULL,
            timestamp DATETIME NOT NULL,
            status VARCHAR(20) NOT NULL,
            notes TEXT NOT NULL,
            initiated_by_id INTEGER NULL,
            FOREIGN KEY (initiated_by_id) REFERENCES users_app_user (id) ON DELETE SET NULL
        );
        """,
        
        # Chat app tables
        """
        CREATE TABLE IF NOT EXISTS chat_app_chatmessage (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            message TEXT NOT NULL,
            is_team_message BOOLEAN NOT NULL,
            timestamp DATETIME NOT NULL,
            file_url VARCHAR(200) NULL,
            file_name VARCHAR(255) NULL,
            is_read BOOLEAN NOT NULL,
            read_timestamp DATETIME NULL,
            recipient_id INTEGER NULL,
            sender_id INTEGER NOT NULL,
            FOREIGN KEY (recipient_id) REFERENCES users_app_user (id) ON DELETE CASCADE,
            FOREIGN KEY (sender_id) REFERENCES users_app_user (id) ON DELETE CASCADE
        );
        """
    ]
    
    # Connect to the database
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    try:
        # Execute each SQL statement
        for sql in sql_statements:
            cursor.execute(sql)
            
        # Record migrations
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
        migrations = [
            ('users_app', '0001_initial', now),
            ('inventory_app', '0001_initial', now),
            ('transfers_app', '0001_initial', now),
            ('chat_app', '0001_initial', now),
            ('core_app', '0001_initial', now)
        ]
        
        cursor.executemany(
            "INSERT INTO django_migrations (app, name, applied) VALUES (?, ?, ?)", 
            migrations
        )
        
        # Commit changes
        conn.commit()
        print("Database tables created successfully!")
    except sqlite3.Error as e:
        print(f"SQLite error: {e}")
        conn.rollback()
    finally:
        conn.close()

def create_admin_user():
    """Create an admin user for the application."""
    print("Creating admin user...")
    
    # Connect to the database
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    try:
        # Check if admin user already exists
        cursor.execute("SELECT id FROM users_app_user WHERE username = 'admin'")
        if cursor.fetchone():
            print("Admin user already exists.")
            return
        
        # Django uses PBKDF2 with SHA256 for passwords, but for simplicity
        # we'll use a pre-generated hash for 'admin_password'
        # In real apps, use Django's password_hasher directly
        password_hash = 'pbkdf2_sha256$600000$VqgJ8qYhoScEXzOAPxvA3L$eTeM9sU/HSAY23KQV3PcbRKB9YhpzpBTtH9P0PIMDRc='
        
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")
        
        # Insert admin user
        cursor.execute("""
            INSERT INTO users_app_user (
                username, password, is_superuser, first_name, last_name, email, 
                is_staff, is_active, date_joined, location_name, last_activity,
                phone_number, is_location_manager, notes
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            'admin', password_hash, 1, '', '', 'admin@example.com', 
            1, 1, now, 'Warehouse', now, '', 0, ''
        ))
        
        # Commit changes
        conn.commit()
        print("Admin user created successfully!")
    except sqlite3.Error as e:
        print(f"SQLite error: {e}")
        conn.rollback()
    finally:
        conn.close()

def main():
    """Main function to initialize the database."""
    # Check if database exists
    if os.path.exists(DB_PATH):
        answer = input("Database already exists. Do you want to recreate it? (y/n): ")
        if answer.lower() == 'y':
            os.remove(DB_PATH)
            print(f"Removed existing database: {DB_PATH}")
        else:
            print("Using existing database.")
            
    # Create tables and admin user
    create_tables()
    create_admin_user()
    
    print("\nDatabase initialization complete.")
    print("You can now start the application with: python manage.py runserver")
    print("\nLogin credentials:")
    print("  Username: admin")
    print("  Password: admin_password")

if __name__ == "__main__":
    main()
