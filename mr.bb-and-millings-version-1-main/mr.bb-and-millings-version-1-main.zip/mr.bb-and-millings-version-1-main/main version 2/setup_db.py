#!/usr/bin/env python
"""
Database setup script for transitioning to modular app structure.
This will create all necessary tables for the new app structure.
"""
import os
import sys
import subprocess
import sqlite3
from pathlib import Path

# Get project root directory
BASE_DIR = Path(__file__).resolve().parent

def run_command(command, description=None):
    """Run a command and print its output."""
    if description:
        print(f"\n>> {description}")
    
    print(f"Running: {' '.join(command)}")
    process = subprocess.run(command, capture_output=True, text=True)
    
    if process.stdout:
        print("Output:")
        print(process.stdout)
    
    if process.stderr:
        print("Errors:")
        print(process.stderr)
    
    return process.returncode == 0

def check_database():
    """Check if the database exists and if it has the necessary tables."""
    db_path = BASE_DIR / 'db.sqlite3'
    
    if not db_path.exists():
        print("Database file doesn't exist. Will create a new one.")
        return False
    
    # Check if the tables exist
    try:
        conn = sqlite3.connect(db_path)
        cursor = conn.cursor()
        
        # Check for users_app_user table
        cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='users_app_user'")
        users_table_exists = cursor.fetchone() is not None
        
        conn.close()
        
        if not users_table_exists:
            print("Database exists but 'users_app_user' table not found.")
            return False
            
        print("Database and required tables already exist.")
        return True
    except Exception as e:
        print(f"Error checking database: {e}")
        return False

def setup_database():
    """Set up a fresh database with all migrations."""
    print("\n=== SETTING UP DATABASE ===\n")
    
    # 1. Check if the database already exists and has necessary tables
    if check_database():
        answer = input("\nDatabase already set up. Do you want to reset it and start fresh? (y/n): ")
        if answer.lower() != 'y':
            print("Keeping existing database. If you have issues, run this script again and choose to reset.")
            return
    
    # 2. Remove old database file if it exists
    db_path = BASE_DIR / 'db.sqlite3'
    if db_path.exists():
        print(f"Removing old database file: {db_path}")
        db_path.unlink()
    
    # 3. Get Python executable path
    python_exe = sys.executable
    
    # 4. Run migrations for all apps
    print("\n=== APPLYING MIGRATIONS ===\n")
    
    # Create empty migrations directories if needed
    for app in ['users_app', 'inventory_app', 'transfers_app', 'chat_app', 'core_app']:
        migrations_dir = BASE_DIR / app / 'migrations'
        migrations_dir.mkdir(exist_ok=True)
        
        # Create __init__.py if it doesn't exist
        init_file = migrations_dir / '__init__.py'
        if not init_file.exists():
            with open(init_file, 'w') as f:
                f.write('# Migrations package initialization\n')
    
    # Apply migrations
    run_command([python_exe, 'manage.py', 'makemigrations', 'users_app'], "Creating migrations for users_app")
    run_command([python_exe, 'manage.py', 'makemigrations', 'inventory_app'], "Creating migrations for inventory_app")
    run_command([python_exe, 'manage.py', 'makemigrations', 'transfers_app'], "Creating migrations for transfers_app")
    run_command([python_exe, 'manage.py', 'makemigrations', 'chat_app'], "Creating migrations for chat_app")
    run_command([python_exe, 'manage.py', 'makemigrations', 'core_app'], "Creating migrations for core_app")
    
    run_command([python_exe, 'manage.py', 'migrate'], "Applying all migrations")
    
    # 5. Create admin user
    print("\n=== CREATING ADMIN USER ===\n")
    run_command([python_exe, 'manage.py', 'shell', '-c',
                "from users_app.models import User; User.objects.create_superuser('admin', 'admin@example.com', 'admin_password', location_name='Warehouse')"],
                "Creating admin superuser")
    
    print("\n=== DATABASE SETUP COMPLETE ===\n")
    print("You can now run the application with:")
    print(f"  {python_exe} manage.py runserver")
    print("\nAdmin user created:")
    print("  Username: admin")
    print("  Password: admin_password")

if __name__ == "__main__":
    setup_database()
