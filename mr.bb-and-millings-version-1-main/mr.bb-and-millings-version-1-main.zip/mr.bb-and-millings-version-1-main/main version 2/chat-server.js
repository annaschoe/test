const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');
const express = require('express');

const app = express();
app.use(cors());

const server = http.createServer(app);
const io = new Server(server, {
    cors: {
        origin: "*", // Adjust for production!
        methods: ["GET", "POST"]
    }
});

let onlineUsers = {};

io.on('connection', (socket) => {
    let user = null;

    socket.on('join', (userData) => {
        user = userData;
        onlineUsers[socket.id] = user;
        io.emit('user_online', user);
        io.emit('online_users', Object.values(onlineUsers));
    });

    socket.on('chat_message', (msg) => {
        // msg: {type, message, recipient_id, is_team_message, ...}
        if (msg.is_team_message) {
            io.emit('chat_message', msg);
        } else if (msg.recipient_id) {
            // Private: send to all sockets of recipient and sender
            for (let [sid, u] of Object.entries(onlineUsers)) {
                if (u.id == msg.recipient_id || u.id == msg.sender_id) {
                    io.to(sid).emit('chat_message', msg);
                }
            }
        }
    });

    socket.on('user_typing', (data) => {
        // data: {recipient_id, is_typing, username, sender_id}
        if (data.recipient_id === 'team' || !data.recipient_id) {
            socket.broadcast.emit('user_typing', data);
        } else {
            for (let [sid, u] of Object.entries(onlineUsers)) {
                if (u.id == data.recipient_id) {
                    io.to(sid).emit('user_typing', data);
                }
            }
        }
    });

    socket.on('disconnect', () => {
        if (user) {
            io.emit('user_offline', user);
            delete onlineUsers[socket.id];
            io.emit('online_users', Object.values(onlineUsers));
        }
    });
});

const PORT = process.env.CHAT_PORT || 5001;
server.listen(PORT, () => {
    console.log(`Socket.IO chat server running on port ${PORT}`);
});
