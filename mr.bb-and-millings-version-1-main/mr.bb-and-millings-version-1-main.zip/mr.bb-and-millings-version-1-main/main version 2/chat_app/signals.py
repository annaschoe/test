"""
Signal handlers for the chat_app.
"""
from django.db.models.signals import post_save
from django.dispatch import receiver
import logging

from chat_app.models import ChatMessage

logger = logging.getLogger('chat')

@receiver(post_save, sender=ChatMessage)
def chat_message_handler(sender, instance, created, **kwargs):
    """Handle chat message events"""
    if created:
        if instance.is_team_message:
            logger.info(f"Team message sent by {instance.sender.username}")
        elif instance.recipient:
            logger.info(f"Private message sent by {instance.sender.username} to {instance.recipient.username}")
        
        # You could trigger additional side effects here, like:
        # - Sending notifications
        # - Updating user activity status
        # - Triggering webhooks
