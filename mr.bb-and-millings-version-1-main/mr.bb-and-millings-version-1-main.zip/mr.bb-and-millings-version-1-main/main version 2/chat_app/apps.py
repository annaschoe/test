from django.apps import AppConfig

class ChatAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'chat_app'
    verbose_name = 'Chat System'
    
    def ready(self):
        """
        Initialize chat app when Django starts.
        """
        # Import signal handlers
        try:
            import chat_app.signals
        except ImportError:
            pass
