# Chat app initialization
