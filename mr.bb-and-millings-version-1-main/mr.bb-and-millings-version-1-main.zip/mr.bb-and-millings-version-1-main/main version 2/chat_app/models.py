from django.db import models
from django.utils import timezone
from users_app.models import User

class ChatMessage(models.Model):
    """Model to store chat messages"""
    sender = models.ForeignKey(User, on_delete=models.CASCADE, related_name='sent_messages')
    recipient = models.ForeignKey(
        User, 
        null=True, 
        blank=True, 
        on_delete=models.CASCADE, 
        related_name='received_messages'
    )
    message = models.TextField(blank=True)
    is_team_message = models.BooleanField(default=False)
    timestamp = models.DateTimeField(default=timezone.now)
    file_url = models.URLField(blank=True, null=True)
    file_name = models.CharField(max_length=255, blank=True, null=True)
    
    # Additional fields
    is_read = models.BooleanField(default=False)
    read_timestamp = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        if self.is_team_message:
            return f"[Team] {self.sender.username}: {self.message}"
        elif self.recipient:
            return f"[Private] {self.sender.username} → {self.recipient.username}: {self.message}"
        else:
            return f"{self.sender.username}: {self.message}"
            
    class Meta:
        ordering = ['-timestamp']
        indexes = [
            models.Index(fields=['sender']),
            models.Index(fields=['recipient']),
            models.Index(fields=['is_team_message']),
        ]
        
    def mark_as_read(self):
        """Mark the message as read"""
        self.is_read = True
        self.read_timestamp = timezone.now()
        self.save(update_fields=['is_read', 'read_timestamp'])
