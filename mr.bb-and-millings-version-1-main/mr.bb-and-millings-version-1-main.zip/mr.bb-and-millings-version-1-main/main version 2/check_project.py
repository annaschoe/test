#!/usr/bin/env python
"""
Utility script to check the Django project structure and diagnose import issues.
"""
import os
import sys
import importlib
import traceback

def check_directory_structure():
    """Check if the directory structure is correct"""
    # Check if we're in the right directory
    current_dir = os.path.basename(os.getcwd())
    parent_dir = os.path.basename(os.path.dirname(os.getcwd()))
    
    print(f"Current directory: {os.getcwd()}")
    print(f"Current dir name: {current_dir}")
    print(f"Parent dir name: {parent_dir}")
    
    if current_dir != "main version 2":
        print("WARNING: You are not in the 'main version 2' directory!")
        print("Change to that directory before running Django commands.")
        return False
    
    # Check for essential project files
    essential_files = [
        'manage.py', 
        os.path.join('festival_project', 'settings.py'),
        os.path.join('festival_project', 'urls.py')
    ]
    
    for file_path in essential_files:
        if not os.path.exists(file_path):
            print(f"ERROR: Essential file '{file_path}' is missing!")
            return False
        else:
            print(f"Found essential file: {file_path}")
    
    return True

def check_python_path():
    """Check if Python path is set up correctly"""
    print("\nChecking Python path:")
    for path in sys.path:
        print(f"  - {path}")
    
    # Add the current directory to the path if it's not already there
    base_dir = os.getcwd()
    if base_dir not in sys.path:
        print(f"\nAdding {base_dir} to Python path")
        sys.path.insert(0, base_dir)

def check_imports():
    """Try to import key modules"""
    modules_to_check = [
        'festival_project.settings',
        'festival_project.urls',
        'festival_app',
        'users_app',
        'inventory_app',
        'transfers_app'
    ]
    
    print("\nTrying to import key modules:")
    for module_name in modules_to_check:
        try:
            module = importlib.import_module(module_name)
            print(f"  ✓ Successfully imported {module_name}")
        except Exception as e:
            print(f"  ✗ Failed to import {module_name}: {e}")
            print("    " + traceback.format_exc().replace('\n', '\n    '))

if __name__ == "__main__":
    print("=== Django Project Structure Check ===\n")
    
    structure_ok = check_directory_structure()
    check_python_path()
    
    if structure_ok:
        check_imports()
        
    print("\n=== Check Complete ===")
    
    if not structure_ok:
        print("\nTo fix, run Django commands from the 'main version 2' directory:")
        print("  cd \"main version 2\"")
        print("  python manage.py runserver")
