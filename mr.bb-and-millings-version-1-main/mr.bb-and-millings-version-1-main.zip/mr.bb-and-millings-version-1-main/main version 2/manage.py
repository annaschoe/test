#!/usr/bin/env python
"""Django's command-line utility for administrative tasks."""
import os
import sys
import socket
import webbrowser

def main():
    """Run administrative tasks."""
    # Make sure we're in the correct directory
    base_dir = os.path.dirname(os.path.abspath(__file__))
    os.chdir(base_dir)
    
    # Add the current directory to the Python path
    if base_dir not in sys.path:
        sys.path.insert(0, base_dir)
    
    # Try multiple settings modules in case of transitional state
    for settings_module in ['festival_project.settings', 'config.settings']:
        try:
            os.environ.setdefault('DJANGO_SETTINGS_MODULE', settings_module)
            from django.core.management import execute_from_command_line
            break
        except ImportError:
            continue
    else:
        # If no settings module is found, use the default one
        os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'festival_project.settings')
        try:
            from django.core.management import execute_from_command_line
        except ImportError as exc:
            raise ImportError(
                "Couldn't import Django. Are you sure it's installed?"
            ) from exc
    
    # Execute the command first to ensure Django is properly initialized
    execute_from_command_line(sys.argv)

if __name__ == '__main__':
    # If running the development server, print access information
    if len(sys.argv) > 1 and sys.argv[1] == 'runserver':
        # Set up automatic admin user creation after Django is initialized
        from django.core.management.commands.runserver import Command as RunserverCommand
        
        original_inner_run = RunserverCommand.inner_run
        
        def custom_inner_run(self, *args, **options):
            # Create admin user if not exists
            self.stdout.write(self.style.SUCCESS("Checking for admin user..."))
            from django.apps import apps
            apps.check_apps_ready()  # Make sure apps are ready
            
            try:
                # Use festival_app.User directly while users_app is not in INSTALLED_APPS
                from users_app.models import User
                from django.contrib.auth.hashers import make_password
                
                if not User.objects.filter(username='admin').exists():
                    self.stdout.write(self.style.SUCCESS("Creating default admin user..."))
                    User.objects.create(
                        username='admin',
                        password=make_password('admin_password'),
                        location_name='Warehouse',
                        is_staff=True,
                        is_superuser=True
                    )
                    self.stdout.write(self.style.SUCCESS("Admin user created successfully!"))
                else:
                    self.stdout.write(self.style.SUCCESS("Admin user already exists."))
            except Exception as e:
                self.stdout.write(self.style.WARNING(f"Could not create admin user: {e}"))
            
            # Call the original inner_run method
            return original_inner_run(self, *args, **options)
        
        # Replace the inner_run method with our custom one
        RunserverCommand.inner_run = custom_inner_run
        
        # Get the port number for the server
        port = 8000
        if len(sys.argv) > 2 and ':' in sys.argv[2]:
            port = int(sys.argv[2].split(':')[1])
        elif len(sys.argv) > 2:
            try:
                port = int(sys.argv[2])
            except ValueError:
                pass
        
        # Get the local IP address
        try:
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            local_ip = s.getsockname()[0]
            s.close()
        except Exception:
            local_ip = "127.0.0.1"
            
        print("\n========================")
        print(f"Starting Django server on: http://{local_ip}:{port}")
        print("========================\n")
        
        # Open browser automatically
        if sys.argv[-1] != 'noreload':  # Don't open browser during reload
            def open_browser():
                try:
                    webbrowser.open(f"http://localhost:{port}")
                    print("\nBrowser opened automatically to application")
                except Exception as e:
                    print(f"\nCould not open browser automatically: {e}")
            
            import threading
            threading.Timer(1.5, open_browser).start()
    
    main()
