#!/usr/bin/env python
"""
Check and fix Python paths for Django.
"""
import os
import sys
import importlib

def check_environment():
    """Check the environment and paths for proper setup"""
    print("\n=== Django Environment Checker ===\n")
    
    # Check current directory
    current_dir = os.getcwd()
    print(f"Current directory: {current_dir}")
    
    # Check if we're in the right directory
    if not current_dir.endswith("main version 2"):
        print("\n⚠️ WARNING: You are not in the 'main version 2' directory!")
        print("This will likely cause Django to fail to find your settings module.")
        print("Please change to this directory with: cd \"main version 2\"")
    
    # Check Python path
    print("\nPython path entries:")
    for i, path in enumerate(sys.path, 1):
        print(f"  {i}. {path}")
    
    # Check for essential modules
    print("\nChecking for essential modules:")
    modules_to_check = [
        "django",
        "festival_project.settings",
        "festival_app",
        "users_app", 
        "inventory_app",
        "transfers_app"
    ]
    
    for module_name in modules_to_check:
        try:
            importlib.import_module(module_name)
            print(f"  ✓ {module_name}: Found")
        except ImportError as e:
            print(f"  ✗ {module_name}: Not found - {str(e)}")
    
    # Check for settings module specifically
    try:
        from django.conf import settings
        print(f"\nDjango settings module: {settings.SETTINGS_MODULE}")
        print(f"Debug mode: {settings.DEBUG}")
        print(f"Installed apps: {len(settings.INSTALLED_APPS)} apps found")
    except Exception as e:
        print(f"\n⚠️ Could not load Django settings: {str(e)}")
    
    print("\n=== End of Environment Check ===\n")

if __name__ == "__main__":
    # Add the current directory to Python path
    base_dir = os.path.dirname(os.path.abspath(__file__))
    if base_dir not in sys.path:
        sys.path.insert(0, base_dir)
    
    check_environment()
    
    print("To fix path issues, try running your Django commands in this directory.")
    print("cd \"main version 2\"")
    print("python manage.py runserver")
