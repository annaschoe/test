# Django project initialization file
