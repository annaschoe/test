"""
Configuration for Django Channels with fallback options.
This module provides a function to get the appropriate channel layer configuration,
falling back to in-memory when Redis is not available.
"""
import socket
import logging

logger = logging.getLogger(__name__)

def is_redis_available(host='127.0.0.1', port=6379, timeout=1):
    """Check if Redis is running and accessible."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.settimeout(timeout)
        s.connect((host, port))
        s.close()
        return True
    except (socket.timeout, socket.error, ConnectionRefusedError):
        return False

def get_channel_layers_config():
    """Return the appropriate channel layers configuration based on Redis availability."""
    if is_redis_available():
        logger.info("Using Redis for Channels")
        return {
            'default': {
                'BACKEND': 'channels_redis.core.RedisChannelLayer',
                'CONFIG': {
                    "hosts": [("127.0.0.1", 6379)],
                },
            },
        }
    else:
        logger.warning(
            "Redis is not available. Using in-memory channel layer instead. "
            "This is NOT suitable for production and will not work across multiple workers."
        )
        return {
            'default': {
                'BACKEND': 'channels.layers.InMemoryChannelLayer',
            },
        }
