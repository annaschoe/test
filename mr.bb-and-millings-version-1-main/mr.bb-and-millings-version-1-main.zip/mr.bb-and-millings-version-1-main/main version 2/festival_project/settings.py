import os
from pathlib import Path
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Build paths inside the project like this: BASE_DIR / 'subdir'.
BASE_DIR = Path(__file__).resolve().parent.parent

# Force any environment variable settings for SECRET_KEY to be ignored
if 'SECRET_KEY' in os.environ:
    del os.environ['SECRET_KEY']

# SECURITY WARNING: keep the secret key used in production secret!
SECRET_KEY = os.getenv('SECRET_KEY', 'default-secret-key')
# IMPORTANT: Do not change SECRET_KEY between server restarts or you will get session corruption errors.
# Do NOT manually edit session data in the database, cache, or files.

# SECURITY WARNING: don't run with debug turned on in production!
DEBUG = os.getenv('DEBUG', 'True').lower() in ('true', '1', 't')

ALLOWED_HOSTS = os.getenv('ALLOWED_HOSTS', 'localhost').split(',')  # For development, restrict in production

# Application definition
INSTALLED_APPS = [
    'django.contrib.admin',
    'django.contrib.auth',
    'django.contrib.contenttypes',
    'django.contrib.sessions',
    'django.contrib.messages',
    'django.contrib.staticfiles',
    
    # Third-party apps
    'widget_tweaks',
    'channels',
    'debug_toolbar',
    'shadcn_django',
    
    # Original app now optional, can be removed when transition is complete
    'festival_app.apps.FestivalAppConfig',
    
    # New modular app structure
    'core_app.apps.CoreAppConfig',
    'users_app.apps.UsersAppConfig',
    'inventory_app.apps.InventoryAppConfig',
    'transfers_app.apps.TransfersAppConfig',
    'chat_app.apps.ChatAppConfig',
]

MIDDLEWARE = [
    'debug_toolbar.middleware.DebugToolbarMiddleware',
    'whitenoise.middleware.WhiteNoiseMiddleware',
    'festival_app.middleware.SecretKeyValidatorMiddleware',
    # must include default session middleware before auth
    'django.contrib.sessions.middleware.SessionMiddleware',
    'festival_app.middleware.SafeSessionMiddleware',
    'festival_app.middleware.ShadcnContextMiddleware',  # Add this middleware
    'django.middleware.common.CommonMiddleware',
    'django.middleware.csrf.CsrfViewMiddleware',
    'django.contrib.auth.middleware.AuthenticationMiddleware',
    'django.contrib.messages.middleware.MessageMiddleware',
    'django.middleware.clickjacking.XFrameOptionsMiddleware',
]

ROOT_URLCONF = 'festival_project.urls'
TEMPLATES = [
    {
        'BACKEND': 'django.template.backends.django.DjangoTemplates',
        'DIRS': [os.path.join(BASE_DIR, 'festival_app', 'templates')],
        'APP_DIRS': True,
        'OPTIONS': {
            'context_processors': [
                'django.template.context_processors.debug',
                'django.template.context_processors.request',
                'django.contrib.auth.context_processors.auth',
                'django.contrib.messages.context_processors.messages',
                'festival_app.context_processors.inject_now',
            ],
        },
    },
]

WSGI_APPLICATION = 'festival_project.wsgi.application'
ASGI_APPLICATION = 'festival_project.asgi.application'

# Database configuration
DATABASES = {
    'default': {
        'ENGINE': 'django.db.backends.sqlite3',
        'NAME': BASE_DIR / 'db.sqlite3',
    }
}
# Auth settings - use the new user model
AUTH_USER_MODEL = 'users_app.User'  # Using the modular User model
LOGIN_URL = '/login/'
LOGIN_REDIRECT_URL = '/dashboard/'
LOGOUT_REDIRECT_URL = '/login/'

# Password validation
AUTH_PASSWORD_VALIDATORS = [
    {'NAME': 'django.contrib.auth.password_validation.UserAttributeSimilarityValidator'},
    {'NAME': 'django.contrib.auth.password_validation.MinimumLengthValidator'},
    {'NAME': 'django.contrib.auth.password_validation.CommonPasswordValidator'},
    {'NAME': 'django.contrib.auth.password_validation.NumericPasswordValidator'},
]

# Internationalization
LANGUAGE_CODE = 'en-us'
TIME_ZONE = 'UTC'
USE_I18N = True
USE_TZ = True

# Static files
STATIC_URL = '/static/'
STATICFILES_DIRS = [os.path.join(BASE_DIR, 'festival_app', 'static')]
STATIC_ROOT = os.path.join(BASE_DIR, 'staticfiles')

# Media files
MEDIA_URL = '/media/'
MEDIA_ROOT = os.path.join(BASE_DIR, 'media')
# Default primary key field type
DEFAULT_AUTO_FIELD = 'django.db.models.BigAutoField'

# Item types
ITEM_TYPES = ["Glass", "Plastic", "Metal", "Other"]

# Channels configuration with fallback
from .channels_config import get_channel_layers_config
CHANNEL_LAYERS = get_channel_layers_config()

# Debug toolbar settings
DEBUG_TOOLBAR_CONFIG = {
    'SHOW_TOOLBAR_CALLBACK': lambda request: DEBUG,
}

# Logging configuration
LOGGING = {
    'version': 1,
    'disable_existing_loggers': False,
    'formatters': {
        'verbose': {
            'format': '%(asctime)s [%(levelname)s] %(name)s: %(message)s'
        },
    },
    'handlers': {
        'file': {
            'level': 'INFO',
            'class': 'logging.FileHandler',
            'filename': os.path.join(BASE_DIR, 'festival.log'),
            'formatter': 'verbose',
        },
    },
    'loggers': {
        'django': {
            'handlers': ['file'],
            'level': 'INFO',
            'propagate': True,
        },
    },
}
SESSION_COOKIE_AGE = 86400 * 7  # 7 days in seconds
# Session settings with more robust handling for chat functionality
SESSION_ENGINE = 'django.contrib.sessions.backends.db'
SESSION_SERIALIZER = 'django.contrib.sessions.serializers.JSONSerializer'
SESSION_COOKIE_AGE = 86400 * 7  # 7 days in seconds
SESSION_EXPIRE_AT_BROWSER_CLOSE = False
SESSION_SAVE_EVERY_REQUEST = True  # Save the session data on every request

# Additional session security for WebSocket interactions
SESSION_COOKIE_SECURE = False  # Set to True in production with HTTPS
SESSION_COOKIE_HTTPONLY = True
SESSION_COOKIE_SAMESITE = 'Lax'  # Helps with CSRF protection
#   4. For chat issues specifically, try logging out and back in.# If you see "Session data corrupted" errors:

#   1. Make sure SECRET_KEY is not changing between server restarts.
#   2. Run: python manage.py clearsessions
#   3. Clear browser cookies for your site.
#   4. For chat issues specifically, try logging out and back in.

# Testing configuration
TEST_RUNNER = 'django.test.runner.DiscoverRunner'

# Configure logging to use our improved format
LOGGING_LEVEL = 'INFO'
LOG_FORMAT = '%(asctime)s [%(levelname)s] %(name)s (%(filename)s:%(lineno)d): %(message)s'

# Feature flags for controlling functionality
ENABLE_ADVANCED_REPORTING = True
ENABLE_FILE_ATTACHMENTS = True
ENABLE_USER_LOCATIONS = True
