import os
import django
from channels.routing import ProtocolTypeRouter, get_default_application
from django.core.asgi import get_asgi_application

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'festival_project.settings')
django.setup()

import festival_project.routing

application = festival_project.routing.application
