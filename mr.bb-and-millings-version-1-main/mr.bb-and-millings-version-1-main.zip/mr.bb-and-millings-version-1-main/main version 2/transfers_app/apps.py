from django.apps import AppConfig

class TransfersAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'transfers_app'
    verbose_name = 'Transfers Management'
    
    def ready(self):
        """
        Initialize transfers app when Django starts.
        """
        # Import signal handlers
        try:
            import transfers_app.signals
        except ImportError:
            pass
