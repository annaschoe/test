"""
Signal handlers for the transfers_app.
"""
from django.db.models.signals import post_save, pre_save
from django.dispatch import receiver
import logging

from transfers_app.models import Transfer

logger = logging.getLogger('transfers')

@receiver(post_save, sender=Transfer)
def transfer_save_handler(sender, instance, created, **kwargs):
    """Log transfer creation and handle any side effects"""
    if created:
        logger.info(f"Transfer created: {instance.quantity} {instance.item} from {instance.from_location} to {instance.to_location}")
    else:
        logger.info(f"Transfer updated: ID {instance.id} - status change to {instance.status}")

@receiver(pre_save, sender=Transfer)
def transfer_pre_save_handler(sender, instance, **kwargs):
    """
    Handle events before a transfer is saved, such as validation.
    This is useful for status transitions.
    """
    if instance.pk:  # If existing instance (not new)
        try:
            old_instance = Transfer.objects.get(pk=instance.pk)
            if old_instance.status != instance.status:
                logger.info(f"Transfer status changing from {old_instance.status} to {instance.status}")
        except Transfer.DoesNotExist:
            pass
