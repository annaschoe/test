# Transfers app initialization
