from django.db import models
from django.core.validators import MinValueValidator
from django.utils import timezone
from users_app.models import User

class Transfer(models.Model):
    """Transfer model for inventory transfers between locations"""
    item = models.CharField(max_length=255)
    from_location = models.CharField(max_length=255)
    to_location = models.CharField(max_length=255)
    quantity = models.IntegerField(validators=[MinValueValidator(1)])
    timestamp = models.DateTimeField(default=timezone.now)
    
    # Additional fields for better tracking
    status = models.CharField(
        max_length=20,
        choices=[
            ('pending', 'Pending'),
            ('completed', 'Completed'),
            ('canceled', 'Canceled'),
        ],
        default='completed'
    )
    initiated_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='initiated_transfers'
    )
    notes = models.TextField(blank=True)

    def __str__(self):
        return f"{self.quantity} {self.item} from {self.from_location} to {self.to_location}"
        
    class Meta:
        ordering = ['-timestamp']
        indexes = [
            models.Index(fields=['item']),
            models.Index(fields=['from_location']),
            models.Index(fields=['to_location']),
        ]
