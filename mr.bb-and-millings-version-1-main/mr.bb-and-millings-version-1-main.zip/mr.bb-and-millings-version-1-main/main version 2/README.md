# Festival Inventory Management System

A comprehensive Django-based inventory management system designed specifically for festivals, allowing multiple location managers to track, transfer, and report on inventory items.

## Table of Contents
- [Overview](#overview)
- [Features](#features)
- [Requirements](#requirements)
- [Installation](#installation)
- [Project Structure](#project-structure)
- [App Migration Guide](#app-migration-guide)
- [How It Works](#how-it-works)
- [Core Components](#core-components)
- [Usage Guide](#usage-guide)
- [Troubleshooting](#troubleshooting)
- [Modular App Structure](#modular-app-structure)

## Overview

This application was developed to solve the challenge of managing inventory across multiple festival locations. It allows staff at different stations (bars, food stalls, warehouses, etc.) to track their inventory, transfer items between locations, and generate reports on inventory changes.

## Features

- **Multi-location inventory tracking**: Each user manages their own location's inventory
- **Real-time inventory transfers**: Transfer items between locations with automatic tracking
- **Visual data analysis**: Charts displaying inventory distribution by type and location
- **Detailed change logging**: Track all inventory changes with timestamps
- **CSV report generation**: Export inventory data, transfers, and change history
- **Responsive design**: Works on desktop and mobile devices

## Requirements

- Python 3.8+
- Django 4.0+
- Additional dependencies listed in `requirements.txt`

## Installation

Follow these steps to set up the project:

1. **Clone the repository:**

```bash
git clone <repository-url>
cd "main version 2"
```

2. **Set up the Python environment:**

   **Option A: Using pipenv (recommended):**
   ```bash
   # Install pipenv if you don't have it
   pip install pipenv
   
   # Create virtual environment and install dependencies
   pipenv install
   
   # Activate the pipenv shell
   pipenv shell
   
   # If requirements.txt exists but no Pipfile
   pipenv install -r requirements.txt
   
   # Install Django directly if needed
   pipenv install django
   ```

   **Option B: Using venv:**
   ```bash
   # Using venv
   python -m venv venv

   # On Windows:
   venv\Scripts\activate

   # On macOS/Linux:
   source venv/bin/activate
   ```

3. **Install dependencies:**

```bash
# If using pipenv (and already in shell):
pipenv install -r requirements.txt

# If using venv:
pip install -r requirements.txt

# If you encounter any issues, you can install Django directly:
pip install django  # or: pipenv install django
```

4. **Verify Django is installed:**

```bash
# This should display the Django version without errors
python -c "import django; print(django.get_version())"
```

5. **Set up the database:**

```bash
python manage.py migrate
```

6. **Create a superuser (admin):**

```bash
python manage.py createsuperuser
```

7. **Run the development server:**

```bash
python manage.py runserver
```

8. **Access the application:**
   - Main application: http://127.0.0.1:8000/
   - Admin interface: http://127.0.0.1:8000/admin/

### Troubleshooting Installation

If you see `ModuleNotFoundError: No module named 'django'` when running commands:

1. Make sure your virtual environment is activated (you should see `(venv)` in your terminal)
2. Install Django: `pip install django`
3. Verify other requirements are installed: `pip install -r requirements.txt`
4. If issues persist, try creating a fresh virtual environment

## Project Structure

The project is organized as follows:

```
festival_project/          # Main project directory
├── festival_project/      # Core Django project settings
│   ├── settings.py        # Project configuration
│   ├── urls.py            # Main URL routing
│   ├── wsgi.py            # WSGI application entry point
│   └── asgi.py            # ASGI application entry point
├── festival_app/          # Main application
│   ├── migrations/        # Database migrations
│   ├── static/            # Static files (CSS, JS)
│   ├── templates/         # HTML templates
│   ├── admin.py           # Admin interface configuration
│   ├── api.py             # API endpoints
│   ├── apps.py            # App configuration
│   ├── forms.py           # Form definitions
│   ├── models.py          # Database models
│   ├── urls.py            # App URL routing
│   ├── utils.py           # Utility functions
│   └── views.py           # View controllers
├── manage.py              # Django management script
└── requirements.txt       # Project dependencies
```

## App Migration Guide

This section is for users migrating from an earlier version of the app.

### Database Changes

- The database schema has been updated. Please run the following commands:

```bash
python manage.py makemigrations
python manage.py migrate
```

### User Model Changes

- The user model has been updated to include additional fields. If you customized the user model, please review the changes in `festival_app/models.py`.

### Inventory Model Changes

- The inventory model now includes a `type` field to categorize items. Existing inventory data will be migrated to include this field.

### Transfer and Change Logging

- The transfer and change logging features have been enhanced. Review the updated views and templates for changes in functionality.

### Frontend Changes

- The frontend has been updated for improved usability. Clear your browser cache after migrating to see the changes.

## How It Works

The application is built around a few key concepts:

1. **Users and Locations**: Each user represents a location (bar, warehouse, etc.)
2. **Inventory**: Each location manages its own inventory items (categorized by type)
3. **Transfers**: Items can be transferred between locations
4. **Change Logging**: All inventory changes are recorded with timestamps

When a user logs in, they are presented with a dashboard showing their inventory breakdown and the inventories at other locations. They can:

- Add, edit, or remove items from their inventory
- Transfer items to another location
- View a history of inventory changes
- Generate reports of inventory data

## Core Components

### Models (`models.py`)

- **User**: Extends Django's user model with location information
- **Inventory**: Stores inventory items with name, quantity, type, and location
- **Transfer**: Records transfers between locations
- **InventoryChange**: Logs all changes to inventory items

### Views (`views.py`)

Handles all user interactions:
- Authentication (login, register, logout)
- Dashboard display with statistics
- Inventory management
- Transfer creation
- Report generation

### Utils (`utils.py`)

Contains utility functions including:
- Inventory transfer logic
- Chart data preparation
- Logging functions

### Templates (`templates/`)

HTML templates with Django template language:
- `base.html`: Base layout template
- `dashboard.html`: Main dashboard
- `inventory.html`: Inventory management
- `transfers.html`: Transfer creation and history
- `inventory_charts.html`: Data visualization
- Plus login/register forms

### Static Files (`static/`)

Contains JavaScript and CSS files for front-end functionality:
- `stats.js`: Handles chart generation and data processing

## Usage Guide

### 1. Registration and Login

- Register with a username, password, and location name
- Each registered user represents a specific location (bar, tent, storage, etc.)

### 2. Dashboard

The dashboard provides:
- Quick statistics about total items and transfers
- Charts showing inventory distribution by type
- Charts showing what other locations have in stock
- Recent inventory changes

### 3. Managing Inventory

- Add new items with name, type, and quantity
- Edit quantities of existing items
- Remove items completely

### 4. Transfers

- Transfer items from your location to another
- View your sent and received transfers
- Generate transfer reports

### 5. Charts and Visualization

- View pie charts of your inventory by type
- View bar charts of what other locations have in stock
- Track inventory distribution across all locations

### 6. Reporting

Generate CSV reports for:
- Current inventory
- Transfer history
- Inventory changes

## Troubleshooting

### Common Issues

1. **Database errors on startup:**
   - Ensure migrations are applied with `python manage.py migrate`

2. **Missing static files:**
   - Run `python manage.py collectstatic`

3. **Charts not showing:**
   - Check browser console for JavaScript errors
   - Ensure you have inventory data to display

4. **Blank page or 500 errors:**
   - Check the Django logs for details
   
5. **Session data corrupted errors:**
   - This typically occurs when the SECRET_KEY changes between server restarts
   - Fix with these commands:
     ```bash
     python manage.py clearsessions
     ```
   - Then clear your browser cookies for the site
   - If issues persist, restart your Django server
   - Make sure environment variables aren't overriding SECRET_KEY in settings.py
   - For chat page issues specifically, logout and login again before accessing chat

## Troubleshooting

### How to ensure frontend and backend chat work together

1. **Django Channels (recommended, default):**
   - Your chat frontend (JavaScript) should connect to the same host/port as your Django ASGI server, using a WebSocket URL like:
     ```
     ws://localhost:8000/ws/chat/
     ```
   - Make sure your JavaScript uses the correct protocol and port. Example:
     ```js
     // Example for native WebSocket (Channels)
     const socket = new WebSocket('ws://' + window.location.host + '/ws/chat/');
     ```
   - If you use Socket.IO in your frontend, you must also run a compatible Socket.IO backend (Node.js or Python-SocketIO). By default, Django Channels does **not** use Socket.IO.

2. **Running the backend:**
   - For Django Channels, run your server with:
     ```bash
     python manage.py runserver
     ```
     or for production:
     ```bash
     daphne festival_project.asgi:application
     ```
   - Ensure your `ASGI_APPLICATION` in `settings.py` is set to `'festival_project.asgi.application'`.

3. **CHANNEL_LAYERS:**
   - For development, `InMemoryChannelLayer` is fine. For production, use Redis:
     ```python
     CHANNEL_LAYERS = {
         'default': {
             'BACKEND': 'channels_redis.core.RedisChannelLayer',
             'CONFIG': {
                 "hosts": [("127.0.0.1", 6379)],
             },
         },
     }
     ```
   - Install with `pip install channels_redis` if using Redis.

4. **Frontend/Backend URL consistency:**
   - The frontend must connect to the backend's WebSocket endpoint. If you use a reverse proxy (nginx), proxy `/ws/` to your ASGI server.
   - Do **not** hardcode `localhost:5001` unless you have a separate Node.js server.

5. **Testing communication:**
   - Open browser dev tools (F12), go to Network tab, filter by "WS" (WebSocket).
   - You should see a successful connection to `/ws/chat/`.
   - If you see errors, check:
     - The server is running and listening on the correct port.
     - No firewall is blocking the port.
     - The frontend URL matches the backend WebSocket endpoint.

6. **Common mistakes:**
   - Using Socket.IO frontend with Django Channels backend (not compatible).
   - Wrong WebSocket URL or port.
   - Not running the Django server with ASGI support.

7. **Summary:**
   - For Django Channels, use native WebSocket in JS and `/ws/chat/` endpoint.
   - For Socket.IO, you need a Socket.IO backend (not Django Channels by default).
   - Always match frontend and backend protocols and endpoints.

## Modular App Structure

The application has been refactored into a modular structure for improved maintainability:

- **users_app**: User authentication and profile management
- **inventory_app**: Inventory item tracking and management
- **transfers_app**: Transfer functionality between locations
- **chat_app**: Real-time communication features
- **core_app**: Shared utilities and core functionality
- **festival_app**: Legacy app containing templates and shared resources

### First-Time Setup After Modular Transition

If you're setting up the project after the transition to the modular structure, run:

```bash
python initialize_project.py
```

This script will:
1. Create necessary migration files
2. Set up the database with the correct table structure
3. Create an admin user with username "admin" and password "admin_password"
4. Configure static files


