#!/usr/bin/env python
"""
Project initialization script for the modular app structure.
This script:
1. Sets up the database structure
2. Creates necessary migrations
3. Configures static files
4. Creates an admin user
"""
import os
import sys
import subprocess
import shutil
from pathlib import Path

# Get project root directory
BASE_DIR = Path(__file__).resolve().parent

def run_command(command, description=None):
    """Run a command and print its output."""
    if description:
        print(f"\n>> {description}")
    
    print(f"Running: {' '.join(command)}")
    process = subprocess.run(command, capture_output=True, text=True)
    
    if process.stdout:
        print("Output:")
        print(process.stdout)
    
    if process.stderr:
        print("Errors:")
        print(process.stderr)
    
    return process.returncode == 0

def setup_project():
    """Initialize the project."""
    # Get Python executable
    python_exe = sys.executable
    
    # 1. Backup the database if it exists
    db_path = BASE_DIR / 'db.sqlite3'
    if db_path.exists():
        backup_file = f"db.sqlite3.backup-{os.urandom(4).hex()}"
        print(f"Backing up database to {backup_file}")
        shutil.copy2(db_path, BASE_DIR / backup_file)
        os.remove(db_path)
    
    # 2. Prepare migrations directories
    for app in ['users_app', 'inventory_app', 'transfers_app', 'chat_app', 'core_app']:
        migrations_dir = BASE_DIR / app / 'migrations'
        migrations_dir.mkdir(exist_ok=True)
        init_file = migrations_dir / '__init__.py'
        if not init_file.exists():
            with open(init_file, 'w') as f:
                f.write('# Migrations package\n')
    
    # 3. Create migrations for user app first
    run_command([python_exe, 'manage.py', 'makemigrations', 'users_app'], 
                "Creating users_app migrations (needed first)")
    
    # 4. Apply users_app migrations first
    run_command([python_exe, 'manage.py', 'migrate', 'users_app'], 
                "Applying users_app migrations")
    
    # 5. Create and apply remaining migrations
    for app in ['inventory_app', 'transfers_app', 'chat_app', 'core_app']:
        run_command([python_exe, 'manage.py', 'makemigrations', app], 
                   f"Creating {app} migrations")
    
    run_command([python_exe, 'manage.py', 'migrate'], 
                "Applying all remaining migrations")
    
    # 6. Collect static files
    run_command([python_exe, 'manage.py', 'collectstatic', '--noinput'], 
                "Collecting static files")
    
    # 7. Create admin superuser
    admin_creation_command = f"""
from users_app.models import User
if not User.objects.filter(username='admin').exists():
    User.objects.create_superuser(
        username='admin',
        email='admin@example.com',
        password='admin_password',
        location_name='Festival HQ'
    )
    print('Admin user created successfully!')
else:
    print('Admin user already exists')
"""
    
    run_command([python_exe, 'manage.py', 'shell', '-c', admin_creation_command], 
                "Creating admin superuser")
    
    print("\n=== PROJECT INITIALIZATION COMPLETE ===")
    print("You can now run the server with:")
    print(f"  {python_exe} manage.py runserver")
    print("\nAdmin user credentials:")
    print("  Username: admin")
    print("  Password: admin_password")

if __name__ == "__main__":
    # Ask for confirmation
    answer = input("This will reset your database and recreate migrations. Continue? (y/n): ")
    if answer.lower() != 'y':
        print("Operation cancelled.")
        sys.exit(0)
    
    setup_project()
