#!/usr/bin/env python
"""
Helper script to create all initial migrations for modular apps.
This resolves dependency issues between apps.
"""
import os
import subprocess
import sys

def run_command(command):
    """Run a command and print output."""
    print(f"Running: {' '.join(command)}")
    result = subprocess.run(command, capture_output=True, text=True)
    
    if result.stdout:
        print("Output:")
        print(result.stdout)
    
    if result.stderr:
        print("Errors:")
        print(result.stderr)
    
    return result.returncode == 0

def create_empty_migrations():
    """Create initial migrations for all apps in the correct order."""
    # Create migrations directory if it doesn't exist
    for app in ['users_app', 'inventory_app', 'transfers_app', 'chat_app', 'core_app']:
        migrations_dir = os.path.join(app, 'migrations')
        os.makedirs(migrations_dir, exist_ok=True)
        
        # Ensure __init__.py exists
        init_file = os.path.join(migrations_dir, '__init__.py')
        if not os.path.exists(init_file):
            with open(init_file, 'w') as f:
                f.write('# Migrations package initialization\n')
                
    print("=== Creating migrations in the correct order ===")
    
    # First, create migration for users_app (the base for other models)
    run_command([sys.executable, 'manage.py', 'makemigrations', 'users_app'])
    
    # Then create migrations for apps that depend on users_app
    run_command([sys.executable, 'manage.py', 'makemigrations', 'inventory_app'])
    run_command([sys.executable, 'manage.py', 'makemigrations', 'transfers_app'])
    run_command([sys.executable, 'manage.py', 'makemigrations', 'chat_app'])
    run_command([sys.executable, 'manage.py', 'makemigrations', 'core_app'])
    
    print("\n=== Apply migrations ===")
    run_command([sys.executable, 'manage.py', 'migrate'])
    
    print("\nMigrations created and applied successfully.")
    print("You can now run the server with: python manage.py runserver")

if __name__ == "__main__":
    create_empty_migrations()
