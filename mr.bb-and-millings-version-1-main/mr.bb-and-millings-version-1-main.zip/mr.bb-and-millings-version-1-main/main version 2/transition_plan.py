#!/usr/bin/env python
"""
Transition plan for moving from festival_app to modular apps.

This script guides you through the steps to safely migrate from the monolithic
festival_app to the new modular app structure.

Usage:
  python transition_plan.py check   - Check environment and prerequisites
  python transition_plan.py prepare - Create initial migrations for modular apps
  python transition_plan.py migrate - Run migrations for all apps
  python transition_plan.py update  - Update imports in your codebase
"""

import os
import sys
import subprocess
import importlib
import re
from pathlib import Path
import shutil

# Get the project directory
BASE_DIR = Path(__file__).resolve().parent

def print_banner(text):
    """Print a section banner with the given text."""
    border = "=" * (len(text) + 6)
    print(f"\n{border}")
    print(f"|| {text} ||")
    print(f"{border}\n")

def check_environment():
    """Check if the environment is properly set up."""
    print_banner("CHECKING ENVIRONMENT")
    
    # Check if we're in the right directory
    print(f"Current directory: {os.getcwd()}")
    
    # Check Django installation
    try:
        import django
        print(f"Django version: {django.get_version()}")
    except ImportError:
        print("ERROR: Django is not installed!")
        return False
    
    # Check for essential files
    essential_files = [
        'manage.py',
        os.path.join('festival_project', 'settings.py'),
        os.path.join('festival_app', 'models.py'),
    ]
    for file_path in essential_files:
        if not os.path.exists(file_path):
            print(f"ERROR: Essential file '{file_path}' is missing!")
            return False
        else:
            print(f"Found essential file: {file_path}")
            
    # Check for modular app directories
    modular_apps = ['core_app', 'users_app', 'inventory_app', 'transfers_app', 'chat_app']
    for app in modular_apps:
        if not os.path.isdir(app):
            print(f"WARNING: Modular app directory '{app}' is missing!")
        else:
            print(f"Found modular app directory: {app}")
    
    # Create any missing modular app directories
    for app in modular_apps:
        if not os.path.isdir(app):
            create_app_structure(app)
    
    # Check database
    try:
        # Create a backup of the database
        if os.path.exists('db.sqlite3'):
            backup_path = f"db.sqlite3.backup.{os.path.getmtime('db.sqlite3'):.0f}"
            shutil.copy2('db.sqlite3', backup_path)
            print(f"Created database backup: {backup_path}")
        else:
            print("WARNING: No database file (db.sqlite3) found.")
    except Exception as e:
        print(f"WARNING: Failed to backup database: {e}")
    
    return True

def create_app_structure(app_name):
    """Create basic structure for a new app."""
    print(f"Creating app structure for {app_name}...")
    
    # Create the app directory
    os.makedirs(app_name, exist_ok=True)
    
    # Create basic app files
    with open(os.path.join(app_name, '__init__.py'), 'w') as f:
        f.write("# App initialization file\n")
    
    # Create migrations directory
    os.makedirs(os.path.join(app_name, 'migrations'), exist_ok=True)
    with open(os.path.join(app_name, 'migrations', '__init__.py'), 'w') as f:
        f.write("# Migrations package initialization\n")
    
    # Create templates directory
    os.makedirs(os.path.join(app_name, 'templates', app_name), exist_ok=True)
    
    # Create basic app files based on app type
    if app_name == 'core_app':
        create_core_app_files(app_name)
    elif app_name == 'users_app':
        create_users_app_files(app_name)
    elif app_name == 'inventory_app':
        create_inventory_app_files(app_name)
    elif app_name == 'transfers_app':
        create_transfers_app_files(app_name)
    elif app_name == 'chat_app':
        create_chat_app_files(app_name)
        
    print(f"App structure created for {app_name}")

def create_core_app_files(app_name):
    """Create files specific to core_app."""
    with open(os.path.join(app_name, 'apps.py'), 'w') as f:
        f.write('''from django.apps import AppConfig

class CoreAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'core_app'
    verbose_name = 'Core Application'
    
    def ready(self):
        """
        Initialize the application when Django starts.
        """
        # Import signal handlers and other initialization 
        try:
            import core_app.signals
        except ImportError:
            pass
''')

def create_users_app_files(app_name):
    """Create files specific to users_app."""
    with open(os.path.join(app_name, 'apps.py'), 'w') as f:
        f.write('''from django.apps import AppConfig

class UsersAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'users_app'
    verbose_name = 'User Management'
    
    def ready(self):
        """
        Initialize users app when Django starts.
        """
        # Import signal handlers
        try:
            import users_app.signals
        except ImportError:
            pass
''')
    
    with open(os.path.join(app_name, 'models.py'), 'w') as f:
        f.write('''from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils import timezone

class User(AbstractUser):
    """User model with location information"""
    location_name = models.CharField(max_length=255, blank=True)
    last_activity = models.DateTimeField(default=timezone.now)
    
    # Additional fields for improved user management
    phone_number = models.CharField(max_length=20, blank=True)
    is_location_manager = models.BooleanField(default=False)
    notes = models.TextField(blank=True)
    
    # Fix the reverse accessor clash with festival_app.User
    groups = models.ManyToManyField(
        'auth.Group',
        verbose_name='groups',
        blank=True,
        help_text='The groups this user belongs to. A user will get all permissions granted to each of their groups.',
        related_name='users_app_user_set',
        related_query_name='users_app_user'
    )
    
    user_permissions = models.ManyToManyField(
        'auth.Permission',
        verbose_name='user permissions',
        blank=True,
        help_text='Specific permissions for this user.',
        related_name='users_app_user_set',
        related_query_name='users_app_user'
    )
    
    def __str__(self):
        return f"{self.username} ({self.location_name})"
        
    class Meta:
        indexes = [
            models.Index(fields=['location_name']),
            models.Index(fields=['is_location_manager']),
        ]
        
    def update_last_activity(self):
        """Update the user's last activity timestamp"""
        self.last_activity = timezone.now()
        self.save(update_fields=['last_activity'])
''')

def create_inventory_app_files(app_name):
    """Create files specific to inventory_app."""
    with open(os.path.join(app_name, 'apps.py'), 'w') as f:
        f.write('''from django.apps import AppConfig

class InventoryAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'inventory_app'
    verbose_name = 'Inventory Management'
    
    def ready(self):
        """
        Initialize inventory app when Django starts.
        """
        # Import signal handlers
        try:
            import inventory_app.signals
        except ImportError:
            pass
''')
    
    with open(os.path.join(app_name, 'models.py'), 'w') as f:
        f.write('''from django.db import models
from django.core.validators import MinValueValidator
from django.utils import timezone
from users_app.models import User

class Inventory(models.Model):
    """Inventory model for storing items"""
    name = models.CharField(max_length=255)
    quantity = models.IntegerField(validators=[MinValueValidator(0)])
    type = models.CharField(max_length=50)
    location = models.ForeignKey(User, on_delete=models.CASCADE, related_name='inventory_items')
    timestamp = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"{self.name} ({self.quantity}) at {self.location.location_name}"
    
    class Meta:
        verbose_name_plural = "Inventories"
        ordering = ['-timestamp']
        indexes = [
            models.Index(fields=['name']),
            models.Index(fields=['type']),
            models.Index(fields=['location']),
        ]

class InventoryChange(models.Model):
    """Model to log inventory changes"""
    item_name = models.CharField(max_length=255)
    action = models.CharField(max_length=50)
    quantity_before = models.IntegerField(null=True, blank=True)
    quantity_after = models.IntegerField(null=True, blank=True)
    location_name = models.CharField(max_length=255)
    timestamp = models.DateTimeField(default=timezone.now)
    
    # Optional fields for improved tracking
    performed_by = models.ForeignKey(
        User, 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True,
        related_name='inventory_changes'
    )
    notes = models.TextField(blank=True)

    def __str__(self):
        return f"{self.action} {self.item_name} at {self.location_name}"
        
    class Meta:
        ordering = ['-timestamp']
        indexes = [
            models.Index(fields=['item_name']),
            models.Index(fields=['action']),
            models.Index(fields=['location_name']),
        ]
''')

def create_transfers_app_files(app_name):
    """Create files specific to transfers_app."""
    with open(os.path.join(app_name, 'apps.py'), 'w') as f:
        f.write('''from django.apps import AppConfig

class TransfersAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'transfers_app'
    verbose_name = 'Transfers Management'
    
    def ready(self):
        """
        Initialize transfers app when Django starts.
        """
        # Import signal handlers
        try:
            import transfers_app.signals
        except ImportError:
            pass
''')
    
    with open(os.path.join(app_name, 'models.py'), 'w') as f:
        f.write('''from django.db import models
from django.core.validators import MinValueValidator
from django.utils import timezone
from users_app.models import User

class Transfer(models.Model):
    """Transfer model for inventory transfers between locations"""
    item = models.CharField(max_length=255)
    from_location = models.CharField(max_length=255)
    to_location = models.CharField(max_length=255)
    quantity = models.IntegerField(validators=[MinValueValidator(1)])
    timestamp = models.DateTimeField(default=timezone.now)
    
    # Additional fields for better tracking
    status = models.CharField(
        max_length=20,
        choices=[
            ('pending', 'Pending'),
            ('completed', 'Completed'),
            ('canceled', 'Canceled'),
        ],
        default='completed'
    )
    initiated_by = models.ForeignKey(
        User,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='initiated_transfers'
    )
    notes = models.TextField(blank=True)

    def __str__(self):
        return f"{self.quantity} {self.item} from {self.from_location} to {self.to_location}"
        
    class Meta:
        ordering = ['-timestamp']
        indexes = [
            models.Index(fields=['item']),
            models.Index(fields=['from_location']),
            models.Index(fields=['to_location']),
        ]
''')

def create_chat_app_files(app_name):
    """Create files specific to chat_app."""
    with open(os.path.join(app_name, 'apps.py'), 'w') as f:
        f.write('''from django.apps import AppConfig

class ChatAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'chat_app'
    verbose_name = 'Chat System'
    
    def ready(self):
        """
        Initialize chat app when Django starts.
        """
        # Import signal handlers
        try:
            import chat_app.signals
        except ImportError:
            pass
''')
    
    with open(os.path.join(app_name, 'models.py'), 'w') as f:
        f.write('''from django.db import models
from django.utils import timezone
from users_app.models import User

class ChatMessage(models.Model):
    """Model to store chat messages"""
    sender = models.ForeignKey(User, on_delete=models.CASCADE, related_name='sent_messages')
    recipient = models.ForeignKey(
        User, 
        null=True, 
        blank=True, 
        on_delete=models.CASCADE, 
        related_name='received_messages'
    )
    message = models.TextField(blank=True)
    is_team_message = models.BooleanField(default=False)
    timestamp = models.DateTimeField(default=timezone.now)
    file_url = models.URLField(blank=True, null=True)
    file_name = models.CharField(max_length=255, blank=True, null=True)
    
    # Additional fields
    is_read = models.BooleanField(default=False)
    read_timestamp = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        if self.is_team_message:
            return f"[Team] {self.sender.username}: {self.message}"
        elif self.recipient:
            return f"[Private] {self.sender.username} → {self.recipient.username}: {self.message}"
        else:
            return f"{self.sender.username}: {self.message}"
            
    class Meta:
        ordering = ['-timestamp']
        indexes = [
            models.Index(fields=['sender']),
            models.Index(fields=['recipient']),
            models.Index(fields=['is_team_message']),
        ]
        
    def mark_as_read(self):
        """Mark the message as read"""
        self.is_read = True
        self.read_timestamp = timezone.now()
        self.save(update_fields=['is_read', 'read_timestamp'])
''')

def run_command(command, description=None):
    """Run a shell command and print the output."""
    if description:
        print(f"\n>> {description}")
    
    print(f"Running: {' '.join(command)}")
    result = subprocess.run(command, capture_output=True, text=True)
    
    if result.stdout:
        print("Output:")
        print(result.stdout)
    
    if result.stderr:
        print("Errors:")
        print(result.stderr)
    
    return result.returncode == 0

def update_settings_for_phase(phase):
    """Update settings.py for the specified migration phase."""
    settings_path = os.path.join(BASE_DIR, 'festival_project', 'settings.py')
    
    with open(settings_path, 'r') as f:
        settings_content = f.read()
    
    # Define the different phases of apps configuration
    app_configs = {
        'initial': """
    # Third-party apps
    'widget_tweaks',
    'channels',
    'debug_toolbar',
    'shadcn_django',
    
    # Keep only the original app for initial migration
    'festival_app.apps.FestivalAppConfig',
    
    # Temporarily comment out new modular apps until we're ready to transition
    # 'core_app.apps.CoreAppConfig',
    # 'users_app.apps.UsersAppConfig',
    # 'inventory_app.apps.InventoryAppConfig',
    # 'transfers_app.apps.TransfersAppConfig',
    # 'chat_app.apps.ChatAppConfig',
""",
        'prepare': """
    # Third-party apps
    'widget_tweaks',
    'channels',
    'debug_toolbar',
    'shadcn_django',
    
    # Original app during transition
    'festival_app.apps.FestivalAppConfig',
    
    # Include modular apps for creating migrations
    'core_app.apps.CoreAppConfig',
    'users_app.apps.UsersAppConfig',
    'inventory_app.apps.InventoryAppConfig',
    'transfers_app.apps.TransfersAppConfig',
    'chat_app.apps.ChatAppConfig',
""",
        'final': """
    # Third-party apps
    'widget_tweaks',
    'channels',
    'debug_toolbar',
    'shadcn_django',
    
    # Original app now optional, can be removed when transition is complete
    'festival_app.apps.FestivalAppConfig',
    
    # New modular app structure
    'core_app.apps.CoreAppConfig',
    'users_app.apps.UsersAppConfig',
    'inventory_app.apps.InventoryAppConfig',
    'transfers_app.apps.TransfersAppConfig',
    'chat_app.apps.ChatAppConfig',
"""
    }
    
    # Also update the AUTH_USER_MODEL based on phase
    auth_models = {
        'initial': "AUTH_USER_MODEL = 'festival_app.User'  # We'll change this later in the transition",
        'prepare': "AUTH_USER_MODEL = 'festival_app.User'  # Keep using original User model during migration preparation",
        'final': "AUTH_USER_MODEL = 'users_app.User'  # Now using the new modular User model"
    }
    
    # Replace the INSTALLED_APPS section
    import re
    app_pattern = re.compile(r'INSTALLED_APPS = \[\s*\'django\.contrib\.admin\',.*?\'chat_app\.apps\.ChatAppConfig\',?\s*\]', re.DOTALL)
    
    # Find the complete INSTALLED_APPS block
    apps_match = re.search(r'INSTALLED_APPS = \[(.*?)\]', settings_content, re.DOTALL)
    if apps_match:
        # Extract the beginning part up to the third-party apps
        apps_start = apps_match.group(0).split("# Third-party apps")[0]
        
        # Construct the new INSTALLED_APPS block
        new_apps_block = f"INSTALLED_APPS = [{apps_start}{app_configs[phase]}]"
        
        # Replace the INSTALLED_APPS block
        settings_content = re.sub(r'INSTALLED_APPS = \[(.*?)\]', new_apps_block, settings_content, flags=re.DOTALL)
    
    # Replace the AUTH_USER_MODEL line
    settings_content = re.sub(
        r'AUTH_USER_MODEL = .*',
        auth_models[phase],
        settings_content
    )
    
    # Write the updated settings
    with open(settings_path, 'w') as f:
        f.write(settings_content)
    
    print(f"Settings updated for phase: {phase}")

def create_migration_script(app_name, migration_name, model_name, model_fields):
    """
    Create a data migration script to transfer data between models.
    
    Args:
        app_name: The app to create the migration for
        migration_name: Name of the migration
        model_name: The model to transfer data to
        model_fields: List of fields to copy from old model to new model
    """
    # Run the makemigrations command to create an empty migration
    result = run_command(
        ['python', 'manage.py', 'makemigrations', app_name, '--empty', '--name', migration_name],
        f"Creating empty migration for {app_name}"
    )
    
    if not result:
        print(f"Failed to create migration for {app_name}")
        return False
    
    # Find the latest migration file
    migrations_dir = os.path.join(app_name, 'migrations')
    migration_files = [f for f in os.listdir(migrations_dir) if f.endswith('.py') and not f.startswith('__')]
    migration_files.sort()
    
    if not migration_files:
        print(f"No migration files found for {app_name}")
        return False
    
    latest_migration = os.path.join(migrations_dir, migration_files[-1])
    
    # Read the migration file
    with open(latest_migration, 'r') as f:
        migration_content = f.read()
    
    # Generate the data transfer operations
    operations_code = """
    # Transfer data from festival_app models to new models
    migrations.RunPython(transfer_data),
"""
    
    # Generate the transfer_data function with dynamic field mapping
    field_assignments = "\n        ".join([f"new_{model_name.lower()}.{field} = old_{model_name.lower()}.{field}" for field in model_fields])
    
    transfer_func = f"""
def transfer_data(apps, schema_editor):
    # Get the old and new model classes
    OldModel = apps.get_model('festival_app', '{model_name}')
    NewModel = apps.get_model('{app_name}', '{model_name}')
    
    # Transfer data from old models to new models
    for old_{model_name.lower()} in OldModel.objects.all():
        # Create corresponding record in the new model
        new_{model_name.lower()} = NewModel(
            id=old_{model_name.lower()}.id,
            {field_assignments}
        )
        new_{model_name.lower()}.save()
"""
    
    # Special handling for User model which has M2M relationships
    if model_name == 'User':
        transfer_func = """
def transfer_data(apps, schema_editor):
    # Get the old and new model classes
    OldUser = apps.get_model('festival_app', 'User')
    NewUser = apps.get_model('users_app', 'User')
    
    # Transfer data from old models to new models
    for old_user in OldUser.objects.all():
        # Create corresponding user in the new model
        new_user = NewUser(
            id=old_user.id,
            username=old_user.username,
            password=old_user.password,
            email=old_user.email,
            first_name=old_user.first_name,
            last_name=old_user.last_name,
            is_staff=old_user.is_staff,
            is_active=old_user.is_active,
            is_superuser=old_user.is_superuser,
            date_joined=old_user.date_joined,
            last_login=old_user.last_login,
            location_name=old_user.location_name
        )
        new_user.save()
        
        # Important: Copy the M2M relationships
        # This must be done after saving the new user
        for group in old_user.groups.all():
            new_user.groups.add(group)
        
        for perm in old_user.user_permissions.all():
            new_user.user_permissions.add(perm)
"""
    
    # Insert operations into the migration file
    updated_content = migration_content.replace(
        'operations = [',
        'operations = [' + operations_code
    )
    
    # Insert the transfer_data function before the Migration class
    updated_content = updated_content.replace(
        'class Migration(migrations.Migration):',
        transfer_func + '\n\nclass Migration(migrations.Migration):'
    )
    
    # Write the updated migration
    with open(latest_migration, 'w') as f:
        f.write(updated_content)
    
    print(f"Data migration script created at {latest_migration}")
    return True

def update_codebase_imports():
    """Update imports throughout the codebase."""
    print_banner("UPDATING IMPORTS")
    
    import_mappings = {
        'from users_app.models import User': 'from users_app.models import User',
        'from inventory_app.models import Inventory': 'from inventory_app.models import Inventory',
        'from transfers_app.models import Transfer': 'from transfers_app.models import Transfer', 
        'from inventory_app.models import InventoryChange': 'from inventory_app.models import InventoryChange',
        'from chat_app.models import ChatMessage': 'from chat_app.models import ChatMessage',
        
        # Handle import variations
        'from users_app.models import User': 'from users_app.models import User',
        'from inventory_app.models import Inventory': 'from inventory_app.models import Inventory',
        'from transfers_app.models import Transfer': 'from transfers_app.models import Transfer',
        'from inventory_app.models import InventoryChange': 'from inventory_app.models import InventoryChange',
        'from chat_app.models import ChatMessage': 'from chat_app.models import ChatMessage',
        
        # Handle bulk imports
        'from users_app.models import User, Inventory': 'from users_app.models import User\nfrom inventory_app.models import Inventory',
        'from users_app.models import User, Transfer': 'from users_app.models import User\nfrom transfers_app.models import Transfer',
        'from users_app.models import User, Inventory, Transfer': 'from users_app.models import User\nfrom inventory_app.models import Inventory\nfrom transfers_app.models import Transfer',
        'from users_app.models import User, Inventory, Transfer, InventoryChange': 'from users_app.models import User\nfrom inventory_app.models import Inventory\nfrom transfers_app.models import Transfer\nfrom inventory_app.models import InventoryChange',
        'from users_app.models import User, Inventory, Transfer, InventoryChange, ChatMessage': 'from users_app.models import User\nfrom inventory_app.models import Inventory\nfrom transfers_app.models import Transfer\nfrom inventory_app.models import InventoryChange\nfrom chat_app.models import ChatMessage',
    }
    
    # Binary file extensions to skip
    binary_extensions = {
        '.pyc', '.pyo', '.so', '.dll', '.exe', '.bin', '.dat', '.db', '.sqlite3',
        '.jpg', '.jpeg', '.png', '.gif', '.bmp', '.ico', '.svg',
        '.pdf', '.doc', '.docx', '.xls', '.xlsx', '.ppt', '.pptx',
        '.zip', '.tar', '.gz', '.bz2', '.7z', '.rar',
        '.mp3', '.mp4', '.avi', '.mov', '.flv', '.wav'
    }
    
    # Python files to scan and update
    python_files = []
    for root, dirs, files in os.walk('.'):
        # Skip directories that shouldn't be processed
        if any(skip_dir in root for skip_dir in ['venv', 'env', '__pycache__', 'migrations', 'media', 'staticfiles']):
            continue
            
        for file in files:
            if file.endswith('.py') and not file.startswith('__'):
                file_path = os.path.join(root, file)
                
                # Skip binary files by extension
                if any(file.endswith(ext) for ext in binary_extensions):
                    continue
                    
                python_files.append(file_path)
    
    # Count the number of files where imports were updated
    files_updated = 0
    files_with_errors = 0
    
    # Process each file
    for file_path in python_files:
        try:
            # Try UTF-8 first (most common for Python files)
            with open(file_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            original_content = content
            
            # Apply all mappings
            for old_import, new_import in import_mappings.items():
                content = content.replace(old_import, new_import)
            
            # If content changed, write back to the file
            if content != original_content:
                with open(file_path, 'w', encoding='utf-8') as f:
                    f.write(content)
                print(f"Updated imports in: {file_path}")
                files_updated += 1
                
        except UnicodeDecodeError:
            # Try with different encodings if UTF-8 fails
            for encoding in ['latin-1', 'cp1252', 'iso-8859-1']:
                try:
                    with open(file_path, 'r', encoding=encoding) as f:
                        content = f.read()
                    
                    original_content = content
                    
                    # Apply all mappings
                    for old_import, new_import in import_mappings.items():
                        content = content.replace(old_import, new_import)
                    
                    # If content changed, write back to the file
                    if content != original_content:
                        with open(file_path, 'w', encoding=encoding) as f:
                            f.write(content)
                        print(f"Updated imports in: {file_path} (encoding: {encoding})")
                        files_updated += 1
                        break
                except Exception:
                    continue
            else:
                # All encodings failed
                print(f"Skipping file due to encoding issues: {file_path}")
                files_with_errors += 1
        except Exception as e:
            print(f"Error processing file {file_path}: {str(e)}")
            files_with_errors += 1
    
    print(f"Updated imports in {files_updated} files")
    if files_with_errors > 0:
        print(f"Encountered errors in {files_with_errors} files")
    
    return files_updated > 0

def safe_read_file(file_path):
    """
    Safely read a file with proper encoding detection.
    
    Args:
        file_path: Path to the file to read
        
    Returns:
        tuple: (content, encoding used, success flag)
    """
    encodings_to_try = ['utf-8', 'latin-1', 'cp1252', 'iso-8859-1']
    
    for encoding in encodings_to_try:
        try:
            with open(file_path, 'r', encoding=encoding) as f:
                content = f.read()
            return content, encoding, True
        except UnicodeDecodeError:
            continue
        except Exception as e:
            print(f"Error reading {file_path}: {str(e)}")
            return None, None, False
    
    # If all encodings fail
    print(f"Could not decode {file_path} with any supported encoding")
    return None, None, False

def test_file_encoding(file_path=None):
    """Test reading a specific file or scan all files for encoding issues."""
    print_banner("TESTING FILE ENCODING")
    
    if file_path:
        # Test reading a specific file
        content, encoding, success = safe_read_file(file_path)
        if success:
            print(f"Successfully read {file_path} with {encoding} encoding")
            print(f"File size: {len(content)} characters")
        else:
            print(f"Failed to read {file_path} with any supported encoding")
    else:
        # Scan all Python files for encoding issues
        problematic_files = []
        for root, dirs, files in os.walk('.'):
            if any(skip_dir in root for skip_dir in ['venv', 'env', '__pycache__', '.git']):
                continue
                
            for file in files:
                if file.endswith('.py'):
                    file_path = os.path.join(root, file)
                    content, encoding, success = safe_read_file(file_path)
                    if not success:
                        problematic_files.append(file_path)
        
        if problematic_files:
            print("Files with encoding issues:")
            for file in problematic_files:
                print(f"  - {file}")
            print(f"\nTotal problematic files: {len(problematic_files)}")
        else:
            print("No files with encoding issues found")

def main():
    """Main function that implements the transition plan."""
    print_banner("FESTIVAL APP TRANSITION PLAN")
    
    if len(sys.argv) > 1:
        command = sys.argv[1].lower()
        
        if command == 'check':
            if check_environment():
                print("\n✅ Environment checks passed.")
            else:
                print("\n❌ Environment checks failed. See errors above.")
            return
        
        elif command == 'prepare':
            print_banner("PREPARING FOR TRANSITION")
            
            # Step 1: Update settings to include modular apps for migration preparation
            update_settings_for_phase('prepare')
            
            # Step 2: Create initial migrations for the modular apps
            run_command(
                ['python', 'manage.py', 'makemigrations', 'core_app', 'users_app', 
                 'inventory_app', 'transfers_app', 'chat_app'],
                "Creating initial migrations for modular apps"
            )
            
            # Step 3: Create data migration scripts
            create_migration_script(
                'users_app', 
                'transfer_users', 
                'User', 
                ['username', 'password', 'email', 'first_name', 'last_name', 'is_staff', 'is_active', 'is_superuser', 'date_joined', 'last_login', 'location_name']
            )
            
            create_migration_script(
                'inventory_app', 
                'transfer_inventory', 
                'Inventory', 
                ['name', 'quantity', 'type', 'location_id', 'timestamp']
            )
            
            create_migration_script(
                'inventory_app', 
                'transfer_inventory_changes', 
                'InventoryChange', 
                ['item_name', 'action', 'quantity_before', 'quantity_after', 'location_name', 'timestamp']
            )
            
            create_migration_script(
                'transfers_app', 
                'transfer_transfers', 
                'Transfer', 
                ['item', 'from_location', 'to_location', 'quantity', 'timestamp']
            )
            
            create_migration_script(
                'chat_app', 
                'transfer_chat_messages', 
                'ChatMessage', 
                ['sender_id', 'recipient_id', 'message', 'is_team_message', 'timestamp', 'file_url', 'file_name']
            )
            
            print("\n✅ Preparation steps completed.")
            print("\nNext steps:")
            print("1. Review the generated migrations")
            print("2. Run 'python transition_plan.py migrate' to apply them")
            
        elif command == 'migrate':
            print_banner("RUNNING MIGRATIONS")
            
            # Migrate the original app first
            run_command(
                ['python', 'manage.py', 'migrate', 'festival_app'],
                "Migrating festival_app first"
            )
            
            # Migrate the modular apps
            run_command(
                ['python', 'manage.py', 'migrate', 'users_app'],
                "Migrating users_app"
            )
            
            run_command(
                ['python', 'manage.py', 'migrate', 'inventory_app'],
                "Migrating inventory_app"
            )
            
            run_command(
                ['python', 'manage.py', 'migrate', 'transfers_app'],
                "Migrating transfers_app"
            )
            
            run_command(
                ['python', 'manage.py', 'migrate', 'chat_app'],
                "Migrating chat_app"
            )
            
            # Update settings to use the new user model
            update_settings_for_phase('final')
            
            print("\n✅ Migration completed.")
            print("\nNext steps:")
            print("1. Test the application thoroughly")
            print("2. Update imports in your codebase - Run 'python transition_plan.py update'")
            print("3. When ready, remove festival_app from INSTALLED_APPS")
            
        elif command == 'update':
            print_banner("UPDATING CODEBASE")
            
            # Update imports in the codebase
            update_codebase_imports()
            
            print("\n✅ Update completed.")
            print("\nNext steps:")
            print("1. Test the application thoroughly")
            print("2. Update any remaining imports manually if needed")
            print("3. When ready, remove festival_app from INSTALLED_APPS")
            
        elif command == 'test-encoding':
            # Check if a specific file was provided
            if len(sys.argv) > 2:
                test_file_encoding(sys.argv[2])
            else:
                test_file_encoding()
        else:
            print(f"Unknown command: {command}")
            print_usage()
    else:
        print_usage()
        
        print("""
=== FESTIVAL APP TRANSITION PLAN ===

Follow these steps in order to safely migrate from the monolithic app to the modular structure:

STEP 1: Migrate the original app first
---------------------------------------
- Ensure only festival_app is in INSTALLED_APPS
- Run: python manage.py migrate
- This establishes your baseline schema

STEP 2: Create migrations for modular apps
------------------------------------------
- Run: python transition_plan.py prepare
- This will:
  - Update settings.py to include the modular apps
  - Create initial migrations
  - Create data migration scripts

STEP 3: Apply migrations
-----------------------
- Run: python transition_plan.py migrate
- This will:
  - Migrate all the apps in the correct order
  - Update settings.py to use the new User model

STEP 4: Complete the transition
-------------------------------
- Run: python transition_plan.py update
- This will:
  - Update imports in your codebase
- Test thoroughly
- When ready, remove festival_app from INSTALLED_APPS

IMPORTANT NOTES:
- Back up your database before starting
- Test on a copy of your database first
- Maintain both sets of models during the transition period
- Update gradually to avoid breaking changes
""")

def print_usage():
    print("Usage:")
    print("  python transition_plan.py check   - Check environment and prerequisites")
    print("  python transition_plan.py prepare - Create initial migrations for modular apps")
    print("  python transition_plan.py migrate - Run migrations for all apps")
    print("  python transition_plan.py update  - Update imports in your codebase")
    print("  python transition_plan.py test-encoding [file] - Test file encoding compatibility")

if __name__ == "__main__":
    main()
