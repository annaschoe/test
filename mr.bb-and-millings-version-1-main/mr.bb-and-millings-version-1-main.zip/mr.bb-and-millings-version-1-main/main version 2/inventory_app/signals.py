"""
Signal handlers for the inventory_app.
"""
from django.db.models.signals import post_save, post_delete
from django.dispatch import receiver
from django.utils import timezone
import logging

from inventory_app.models import Inventory, InventoryChange

logger = logging.getLogger('inventory')

@receiver(post_save, sender=Inventory)
def inventory_save_handler(sender, instance, created, **kwargs):
    """
    Log inventory changes and can automatically create
    change records when needed.
    """
    if created:
        logger.info(f"New inventory item added: {instance.name} at {instance.location.location_name}")
    else:
        logger.info(f"Inventory updated: {instance.name} at {instance.location.location_name}")

@receiver(post_delete, sender=Inventory)
def inventory_delete_handler(sender, instance, **kwargs):
    """Log when inventory items are deleted"""
    logger.info(f"Inventory deleted: {instance.name} from {instance.location.location_name}")
    
    # Optionally create a deletion record
    InventoryChange.objects.create(
        item_name=instance.name,
        action='deleted',
        quantity_before=instance.quantity,
        quantity_after=None,
        location_name=instance.location.location_name
    )
