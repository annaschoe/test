# Inventory app initialization
