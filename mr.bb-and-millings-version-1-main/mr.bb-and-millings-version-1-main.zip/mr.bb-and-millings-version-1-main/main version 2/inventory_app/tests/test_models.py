import pytest
from inventory_app.models import Inventory, InventoryChange
from users_app.models import User

@pytest.mark.django_db
class TestInventoryModel:
    
    def test_inventory_creation(self):
        # Create a test user
        user = User.objects.create(
            username="test_user",
            location_name="Test Location"
        )
        
        # Create inventory item
        inventory = Inventory.objects.create(
            name="Test Item",
            quantity=10,
            type="Glass",
            location=user
        )
        
        # Assert
        assert inventory.name == "Test Item"
        assert inventory.quantity == 10
        assert inventory.type == "Glass"
        assert inventory.location == user
        assert str(inventory) == "Test Item (10) at Test Location"
    
    def test_inventory_quantity_validation(self):
        # Create a test user
        user = User.objects.create(
            username="test_user",
            location_name="Test Location"
        )
        
        # Test creating an inventory with negative quantity
        with pytest.raises(Exception):
            Inventory.objects.create(
                name="Test Item",
                quantity=-5,  # Should fail validation
                type="Glass",
                location=user
            )

@pytest.mark.django_db
class TestInventoryChangeModel:
    
    def test_inventory_change_creation(self):
        # Create inventory change record
        change = InventoryChange.objects.create(
            item_name="Test Item",
            action="added",
            quantity_before=None,
            quantity_after=10,
            location_name="Test Location"
        )
        
        # Assert
        assert change.item_name == "Test Item"
        assert change.action == "added"
        assert change.quantity_before is None
        assert change.quantity_after == 10
        assert change.location_name == "Test Location"
        assert str(change) == "added Test Item at Test Location"
    
    def test_inventory_change_with_user(self):
        # Create a test user
        user = User.objects.create(
            username="test_user",
            location_name="Test Location"
        )
        
        # Create inventory change with user
        change = InventoryChange.objects.create(
            item_name="Test Item",
            action="edited",
            quantity_before=5,
            quantity_after=10,
            location_name="Test Location",
            performed_by=user,
            notes="Changed quantity due to recount"
        )
        
        # Assert
        assert change.performed_by == user
        assert change.notes == "Changed quantity due to recount"
