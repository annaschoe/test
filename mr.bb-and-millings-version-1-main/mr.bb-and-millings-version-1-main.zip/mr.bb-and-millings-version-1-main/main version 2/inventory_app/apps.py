from django.apps import AppConfig

class InventoryAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'inventory_app'
    verbose_name = 'Inventory Management'
    
    def ready(self):
        """
        Initialize inventory app when Django starts.
        """
        # Import signal handlers
        try:
            import inventory_app.signals
        except ImportError:
            pass
