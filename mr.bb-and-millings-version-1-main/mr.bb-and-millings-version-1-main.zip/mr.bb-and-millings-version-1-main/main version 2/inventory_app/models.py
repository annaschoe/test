from django.db import models
from django.core.validators import MinValueValidator
from django.utils import timezone
from users_app.models import User

class Inventory(models.Model):
    """Inventory model for storing items"""
    name = models.CharField(max_length=255)
    quantity = models.IntegerField(validators=[MinValueValidator(0)])
    type = models.CharField(max_length=50)
    location = models.ForeignKey(User, on_delete=models.CASCADE, related_name='inventory_items')
    timestamp = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"{self.name} ({self.quantity}) at {self.location.location_name}"
    
    class Meta:
        verbose_name_plural = "Inventories"
        ordering = ['-timestamp']
        indexes = [
            models.Index(fields=['name']),
            models.Index(fields=['type']),
            models.Index(fields=['location']),
        ]

class InventoryChange(models.Model):
    """Model to log inventory changes"""
    item_name = models.CharField(max_length=255)
    action = models.CharField(max_length=50)
    quantity_before = models.IntegerField(null=True, blank=True)
    quantity_after = models.IntegerField(null=True, blank=True)
    location_name = models.CharField(max_length=255)
    timestamp = models.DateTimeField(default=timezone.now)
    
    # Optional fields for improved tracking
    performed_by = models.ForeignKey(
        User, 
        on_delete=models.SET_NULL, 
        null=True, 
        blank=True,
        related_name='inventory_changes'
    )
    notes = models.TextField(blank=True)

    def __str__(self):
        return f"{self.action} {self.item_name} at {self.location_name}"
        
    class Meta:
        ordering = ['-timestamp']
        indexes = [
            models.Index(fields=['item_name']),
            models.Index(fields=['action']),
            models.Index(fields=['location_name']),
        ]
