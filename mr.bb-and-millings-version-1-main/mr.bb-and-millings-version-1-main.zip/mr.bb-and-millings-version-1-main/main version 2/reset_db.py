#!/usr/bin/env python
"""
Database reset script to fix migration inconsistencies.
This script will:
1. Delete the existing database
2. Create a fresh database
3. Apply migrations in the correct order
4. Create an admin user
"""
import os
import sys
import subprocess
from pathlib import Path

# Get the project root directory
BASE_DIR = Path(__file__).resolve().parent

def run_command(command, description=None, show_output=True):
    """Run a shell command and return success status."""
    if description and show_output:
        print(f"\n>> {description}")
    
    if show_output:
        print(f"Running: {' '.join(command)}")
    
    process = subprocess.run(command, capture_output=True, text=True)
    
    if show_output:
        if process.stdout:
            print("Output:")
            print(process.stdout)
        
        if process.stderr:
            print("Errors:")
            print(process.stderr)
    
    return process.returncode == 0

def reset_database():
    """Reset the database and apply migrations in the correct order."""
    print("\n=== DATABASE RESET SCRIPT ===\n")
    
    # 1. Delete the existing database
    db_path = BASE_DIR / 'db.sqlite3'
    if db_path.exists():
        print(f"Removing existing database: {db_path}")
        os.remove(db_path)
    
    # 2. Create and prepare migrations directories
    for app in ['users_app', 'inventory_app', 'transfers_app', 'chat_app', 'core_app']:
        migrations_dir = BASE_DIR / app / 'migrations'
        migrations_dir.mkdir(exist_ok=True)
        
        init_file = migrations_dir / '__init__.py'
        if not init_file.exists():
            with open(init_file, 'w') as f:
                f.write('# Migrations package\n')
    
    # 3. Create initial migrations
    print("\n=== CREATING MIGRATIONS ===\n")
    
    # First, create migrations for the users_app (this needs to be done first)
    run_command(
        [sys.executable, 'manage.py', 'makemigrations', 'users_app'],
        "Creating users_app migrations (needed first for auth dependencies)"
    )
    
    # Apply the users_app migrations first (before admin)
    run_command(
        [sys.executable, 'manage.py', 'migrate', 'users_app'],
        "Applying users_app migrations first (before admin)"
    )
    
    # Then create and migrate the other apps
    for app in ['inventory_app', 'transfers_app', 'chat_app', 'core_app']:
        run_command(
            [sys.executable, 'manage.py', 'makemigrations', app],
            f"Creating {app} migrations"
        )
    
    # Now that users_app is migrated, migrate all other apps
    run_command(
        [sys.executable, 'manage.py', 'migrate'],
        "Applying all remaining migrations"
    )
    
    # 4. Create admin user
    print("\n=== CREATING ADMIN USER ===\n")
    from django.contrib.auth.hashers import make_password
    
    # Try to run a Python command to create a superuser
    admin_creation_command = f"""
from users_app.models import User;
User.objects.create_superuser(
    username='admin',
    email='admin@example.com',
    password='admin_password',
    location_name='Warehouse'
)
print('Admin user created successfully!')
"""
    
    run_command(
        [sys.executable, 'manage.py', 'shell', '-c', admin_creation_command],
        "Creating admin superuser"
    )
    
    print("\n=== DATABASE RESET COMPLETE ===\n")
    print("You can now start the application with:")
    print(f"  {sys.executable} manage.py runserver")
    print("\nAdmin user credentials:")
    print("  Username: admin")
    print("  Password: admin_password")

if __name__ == "__main__":
    # Check if user wants to proceed
    confirmation = input("This will reset your database and delete all existing data. Proceed? (y/n): ")
    if confirmation.lower() != 'y':
        print("Operation cancelled.")
        sys.exit(0)
    
    reset_database()
