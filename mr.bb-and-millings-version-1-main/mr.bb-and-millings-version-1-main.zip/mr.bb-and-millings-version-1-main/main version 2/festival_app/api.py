from django.http import JsonResponse
from django.contrib.auth.decorators import login_required
from django.db.models import Sum, Count
from datetime import datetime

# Fix imports to use correct modules
from users_app.models import User
from inventory_app.models import Inventory, InventoryChange
from transfers_app.models import Transfer

@login_required
def dashboard_data(request):
    """API endpoint for dashboard charts"""
    # Get data for inventory by location chart
    by_location = User.objects.annotate(
        total=Sum('inventory_items__quantity', default=0)
    ).values('location_name', 'total')
    
    # Get data for inventory by type chart
    by_type = Inventory.objects.values('type').annotate(
        total=Count('id')
    ).values('type', 'total')
    
    # Get data for recent transfers
    recent_transfers = Transfer.objects.order_by('-timestamp')[:10].values(
        'item', 'from_location', 'to_location', 'quantity', 'timestamp'
    )
    
    # Format datetime objects for JSON serialization
    formatted_transfers = []
    for transfer in recent_transfers:
        transfer_dict = dict(transfer)
        transfer_dict['timestamp'] = transfer['timestamp'].strftime('%Y-%m-%d %H:%M:%S')
        formatted_transfers.append(transfer_dict)
    
    return JsonResponse({
        'by_location': list(by_location),
        'by_type': list(by_type),
        'recent_transfers': formatted_transfers
    })

@login_required
def stats_data(request):
    """API endpoint for overall statistics"""
    total_items = Inventory.objects.count()
    total_quantity = Inventory.objects.aggregate(total=Sum('quantity'))['total'] or 0
    total_transfers = Transfer.objects.count()
    total_locations = User.objects.count()
    
    return JsonResponse({
        'totalItems': total_items,
        'totalQuantity': total_quantity,
        'totalTransfers': total_transfers,
        'totalLocations': total_locations,
        'averagePerLocation': total_quantity / total_locations if total_locations > 0 else 0
    })

@login_required
def upload_chat_file(request):
    """API endpoint for chat file uploads"""
    if request.method != 'POST' or 'file' not in request.FILES:
        return JsonResponse({'error': 'Invalid request'}, status=400)
    
    file = request.FILES['file']
    recipient_id = request.POST.get('recipient_id')
    
    # Save file to media - in production you would use a proper file storage system
    import os
    from django.conf import settings
    
    # Create directory if it doesn't exist
    upload_dir = os.path.join(settings.MEDIA_ROOT, 'chat_files')
    os.makedirs(upload_dir, exist_ok=True)
    
    # Save file with unique name
    import uuid
    file_ext = os.path.splitext(file.name)[1]
    unique_filename = f"{uuid.uuid4()}{file_ext}"
    file_path = os.path.join(upload_dir, unique_filename)
    
    with open(file_path, 'wb+') as destination:
        for chunk in file.chunks():
            destination.write(chunk)
    
    # Generate file URL
    file_url = f"{settings.MEDIA_URL}chat_files/{unique_filename}"
    
    # Notify users about the file through WebSocket
    from channels.layers import get_channel_layer
    from asgiref.sync import async_to_sync
    import json
    
    channel_layer = get_channel_layer()
    
    # Create message data
    message_data = {
        "type": "chat_message",
        "sender_id": str(request.user.id),
        "sender_username": request.user.username,
        "sender_location": request.user.location_name,
        "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "is_file": True,
        "file_url": file_url,
        "file_name": file.name,
        "message": f"File: {file.name}"
    }
    
    # Send to appropriate recipients
    if recipient_id == 'team':
        message_data["is_team_message"] = True
        async_to_sync(channel_layer.group_send)("chat_general", message_data)
    else:
        message_data["is_team_message"] = False
        message_data["recipient_id"] = recipient_id
        
        # Send to recipient
        recipient_group = f"user_{recipient_id}"
        async_to_sync(channel_layer.group_send)(recipient_group, message_data)
        
        # Also send to sender
        sender_group = f"user_{request.user.id}"
        async_to_sync(channel_layer.group_send)(sender_group, message_data)
    
    return JsonResponse({'success': True, 'fileUrl': file_url})
