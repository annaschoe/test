from django.db import models
from django.contrib.auth.models import AbstractUser
from django.core.validators import MinValueValidator
from django.utils import timezone

class User(AbstractUser):
    """User model with location information"""
    location_name = models.CharField(max_length=255, blank=True)
    
    def __str__(self):
        return f"{self.username} ({self.location_name})"

class Inventory(models.Model):
    """Inventory model for storing items"""
    name = models.CharField(max_length=255)
    quantity = models.IntegerField(validators=[MinValueValidator(0)])
    type = models.CharField(max_length=50)
    location = models.ForeignKey(User, on_delete=models.CASCADE, related_name='inventory_items')
    timestamp = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"{self.name} ({self.quantity}) at {self.location.location_name}"
    
    class Meta:
        verbose_name_plural = "Inventories"

class Transfer(models.Model):
    """Transfer model for inventory transfers between locations"""
    item = models.CharField(max_length=255)
    from_location = models.CharField(max_length=255)
    to_location = models.CharField(max_length=255)
    quantity = models.IntegerField(validators=[MinValueValidator(1)])
    timestamp = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"{self.quantity} {self.item} from {self.from_location} to {self.to_location}"

class InventoryChange(models.Model):
    """Model to log inventory changes"""
    item_name = models.CharField(max_length=255)
    action = models.CharField(max_length=50)
    quantity_before = models.IntegerField(null=True, blank=True)
    quantity_after = models.IntegerField(null=True, blank=True)
    location_name = models.CharField(max_length=255)
    timestamp = models.DateTimeField(default=timezone.now)

    def __str__(self):
        return f"{self.action} {self.item_name} at {self.location_name}"

class ChatMessage(models.Model):
    """Model to store chat messages"""
    sender = models.ForeignKey(User, on_delete=models.CASCADE, related_name='sent_messages')
    recipient = models.ForeignKey(User, null=True, blank=True, on_delete=models.CASCADE, related_name='received_messages')
    message = models.TextField(blank=True)
    is_team_message = models.BooleanField(default=False)
    timestamp = models.DateTimeField(default=timezone.now)
    file_url = models.URLField(blank=True, null=True)
    file_name = models.CharField(max_length=255, blank=True, null=True)

    def __str__(self):
        if self.is_team_message:
            return f"[Team] {self.sender.username}: {self.message}"
        elif self.recipient:
            return f"[Private] {self.sender.username} → {self.recipient.username}: {self.message}"
        else:
            return f"{self.sender.username}: {self.message}"

class DamagedItem(models.Model):
    name = models.CharField(max_length=255)
    quantity = models.PositiveIntegerField()
    location = models.CharField(max_length=255)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} (Damaged) - {self.quantity} units at {self.location}"

class OpenedItem(models.Model):
    name = models.CharField(max_length=255)
    quantity = models.PositiveIntegerField()
    location = models.CharField(max_length=255)
    user = models.ForeignKey(User, on_delete=models.CASCADE)
    timestamp = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.name} (Opened) - {self.quantity} units at {self.location}"
