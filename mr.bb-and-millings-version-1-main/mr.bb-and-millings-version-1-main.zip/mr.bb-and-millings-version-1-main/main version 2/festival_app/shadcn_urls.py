from django.urls import path
from . import views

# This file can be used to define any custom routes for shadcn UI components
# For now, it's empty as we're directly integrating shadcn in our templates

urlpatterns = [
    # Example: path('buttons/', views.shadcn_buttons, name='shadcn_buttons'),
]
