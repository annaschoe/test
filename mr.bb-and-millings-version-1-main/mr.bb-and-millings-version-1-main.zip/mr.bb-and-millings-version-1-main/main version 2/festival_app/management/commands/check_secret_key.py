from django.core.management.base import BaseCommand
from django.conf import settings
import os

class Command(BaseCommand):
    help = 'Verify the SECRET_KEY consistency and show session settings'

    def handle(self, *args, **options):
        self.stdout.write(self.style.SUCCESS('===== SECRET_KEY Diagnostics ====='))
        
        # Check environment variables
        env_secret = os.environ.get('SECRET_KEY', None)
        self.stdout.write(f"SECRET_KEY in environment: {'PRESENT (POTENTIAL ISSUE)' if env_secret else 'ABSENT (GOOD)'}")
        
        # Display the current SECRET_KEY (hash for security)
        self.stdout.write(f"Current SECRET_KEY hash: {hash(settings.SECRET_KEY)}")
        self.stdout.write(f"Expected hash: {hash('developmentkey')}")
        
        if hash(settings.SECRET_KEY) != hash('developmentkey'):
            self.stdout.write(self.style.ERROR("ERROR: SECRET_KEY doesn't match the expected value!"))
        else:
            self.stdout.write(self.style.SUCCESS("SECRET_KEY matches expected value."))
        
        # Display session settings
        self.stdout.write("\n===== Session Settings =====")
        self.stdout.write(f"SESSION_ENGINE: {settings.SESSION_ENGINE}")
        self.stdout.write(f"SESSION_SERIALIZER: {settings.SESSION_SERIALIZER}")
        self.stdout.write(f"SESSION_COOKIE_AGE: {settings.SESSION_COOKIE_AGE} seconds")
        self.stdout.write(f"SESSION_SAVE_EVERY_REQUEST: {settings.SESSION_SAVE_EVERY_REQUEST}")
        
        self.stdout.write("\n===== Next Steps =====")
        self.stdout.write("1. If issues persist, run: python manage.py clearsessions")
        self.stdout.write("2. Clear your browser cookies")
        self.stdout.write("3. Restart the Django server with: python manage.py runserver")
