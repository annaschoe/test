from django.contrib import admin
from users_app.models import User
from inventory_app.models import Inventory
from transfers_app.models import Transfer

@admin.register(User)
class UserAdmin(admin.ModelAdmin):
    list_display = ('username', 'location_name', 'email')
    search_fields = ('username', 'location_name')

@admin.register(Inventory)
class InventoryAdmin(admin.ModelAdmin):
    list_display = ('name', 'quantity', 'type', 'location')
    list_filter = ('type',)
    search_fields = ('name',)

@admin.register(Transfer)
class TransferAdmin(admin.ModelAdmin):
    list_display = ('item', 'from_location', 'to_location', 'quantity')
    search_fields = ('item',)
