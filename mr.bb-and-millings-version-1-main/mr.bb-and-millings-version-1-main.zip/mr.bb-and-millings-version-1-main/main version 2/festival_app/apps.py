from django.apps import AppConfig
import logging

class FestivalAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'festival_app'
    verbose_name = 'Festival Inventory Management'
    
    def ready(self):
        """
        Perform initialization tasks when the Django app registry is ready.
        This is a good place for any app-specific startup logic.
        """
        # Import signals with better error handling
        try:
            # Using an explicit relative import for clarity
            from . import signals
            # Access the module to suppress "imported but unused" warnings
            assert signals
        except ImportError as e:
            logging.warning(f"Failed to import signals module: {e}")
            pass  # Continue without signals during setup
