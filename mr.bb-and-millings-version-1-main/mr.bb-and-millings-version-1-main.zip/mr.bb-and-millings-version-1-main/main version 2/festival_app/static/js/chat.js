// Use native WebSocket for Django Channels chat
const chatSocket = new WebSocket(
    'ws://' + window.location.host + '/ws/chat/'
);

chatSocket.onopen = function(e) {
    console.log('WebSocket connection established.');
};

chatSocket.onmessage = function(e) {
    const data = JSON.parse(e.data);
    // Handle incoming chat message (update UI as needed)
    // Example:
    // addMessageToChat(data.username, data.message);
};

chatSocket.onclose = function(e) {
    console.log('WebSocket connection closed.');
};

chatSocket.onerror = function(e) {
    console.error('WebSocket error:', e);
};

// To send a message:
function sendChatMessage(message) {
    chatSocket.send(JSON.stringify({
        'message': message
    }));
}
