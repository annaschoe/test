const statsData = {
    totalVisitors: 5000,
    totalRevenue: 200000,
    averageSpend: 40
};

function calculateStats(data) {
    // Use statsData instead of redeclaring 'stats'
    const result = {
        total: data.totalVisitors,
        revenue: data.totalRevenue,
        // Add average calculation for Django integration
        average: data.totalRevenue / data.totalVisitors
    };
    return result;
}

// Export for Django integration
if (typeof module !== 'undefined') {
    module.exports = { calculateStats, statsData };
}
