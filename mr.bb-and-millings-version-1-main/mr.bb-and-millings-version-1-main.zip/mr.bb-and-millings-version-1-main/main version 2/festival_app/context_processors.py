from datetime import datetime

def inject_now(request):
    """Add current datetime to the template context"""
    return {"now": datetime.now()}
