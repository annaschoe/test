from django.conf import settings
import logging

class SecretKeyValidatorMiddleware:
    """Middleware to ensure SECRET_KEY doesn't change between requests."""
    
    def __init__(self, get_response):
        self.get_response = get_response
        self.original_secret_key = settings.SECRET_KEY

    def __call__(self, request):
        # Check if SECRET_KEY has changed, which would cause session issues
        if settings.SECRET_KEY != self.original_secret_key:
            # Log a warning - don't reset it as it would cause more issues with current requests
            import logging
            logger = logging.getLogger(__name__)
            logger.warning("SECRET_KEY has changed since server start. This will cause session corruption.")
            
        response = self.get_response(request)
        return response

class SafeSessionMiddleware:
    """Middleware to safely handle session errors."""
    
    def __init__(self, get_response):
        self.get_response = get_response

    def __call__(self, request):
        try:
            # Safely access session data
            if hasattr(request, 'session') and request.session:
                # Just try to access session keys to check if it's valid
                list(request.session.keys())
        except Exception as e:
            # If there's a session error, log it and reset the session
            import logging
            logger = logging.getLogger(__name__)
            logger.error(f"Session error: {str(e)}. Resetting session.")
            
            # Delete the corrupted session cookie
            request.COOKIES.pop(settings.SESSION_COOKIE_NAME, None)
            
            # By not accessing the session further, a new clean session will be created

        response = self.get_response(request)
        return response

class ShadcnContextMiddleware:
    """Add shadcn context to all template rendering."""
    
    def __init__(self, get_response):
        self.get_response = get_response
        # Check if shadcn is properly installed
        try:
            import shadcn_django
            self.shadcn_available = True
        except ImportError:
            self.shadcn_available = False

    def __call__(self, request):
        # Make shadcn availability status available in templates
        request.shadcn_available = self.shadcn_available
        return self.get_response(request)
