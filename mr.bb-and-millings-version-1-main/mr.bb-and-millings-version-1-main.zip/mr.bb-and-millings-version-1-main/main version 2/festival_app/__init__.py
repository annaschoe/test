# Django app initialization file
