from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.http import HttpResponse, JsonResponse
from django.urls import reverse
from django.utils import timezone
from django.conf import settings
from django.db.models import Count, Sum
import json
from django.db import models

import csv
import io
from datetime import datetime

# Import models from their correct modular app locations
from users_app.models import User
from inventory_app.models import Inventory, InventoryChange
from transfers_app.models import Transfer
from chat_app.models import ChatMessage

from .forms import (
    CustomUserCreationForm, CustomAuthenticationForm, 
    InventoryForm, TransferForm, EditQuantityForm
)
from .utils import (
    transfer_items, record_inventory_change, 
    get_user_inventory_chart_data, get_other_users_inventory_chart_data
)
from django.contrib.sessions.models import Session
from django.utils import timezone
from .models import DamagedItem, OpenedItem  # Husk at oprette disse modeller

# Authentication views
def login_view(request):
    """Handle user login"""
    if request.method == 'POST':
        form = CustomAuthenticationForm(request, data=request.POST)
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            user = authenticate(username=username, password=password)
            if user is not None:
                login(request, user)
                messages.info(request, f"You are now logged in as {username}")
                return redirect('dashboard')
            else:
                messages.error(request, "Invalid username or password")
        else:
            messages.error(request, "Invalid username or password")
    else:
        form = CustomAuthenticationForm()
    return render(request, 'login.html', {'form': form})

def register_view(request):
    """Handle user registration"""
    if request.method == 'POST':
        form = CustomUserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            messages.success(request, "Registration successful!")
            return redirect('dashboard')
        else:
            for msg in form.error_messages:
                messages.error(request, f"{msg}: {form.error_messages[msg]}")
    else:
        form = CustomUserCreationForm()
    return render(request, 'register.html', {'form': form})

@login_required
def logout_view(request):
    """Handle user logout"""
    logout(request)
    messages.info(request, "You have been logged out.")
    return redirect('login')

# Dashboard and routes
@login_required
def index(request):
    """Redirect to dashboard"""
    return redirect('dashboard')

@login_required
def dashboard(request):
    """Dashboard with statistics and recent activity"""
    # Get statistics
    total_items = Inventory.objects.count()
    total_transfers = Transfer.objects.count()
    
    # Get data for charts using the utility functions
    user_inventory_data = get_user_inventory_chart_data(request.user)
    other_users_data = get_other_users_inventory_chart_data(request.user)
    
    # Get recent changes
    changes = InventoryChange.objects.filter(
        location_name=request.user.location_name
    ).order_by('-timestamp')[:5]
    
    context = {
        'stats': {
            'total_items': total_items,
            'total_transfers': total_transfers,
        },
        'user_inventory_data': user_inventory_data,
        'other_users_data': other_users_data,
        'changes': changes
    }
    
    return render(request, 'dashboard.html', context)

# Inventory views
@login_required
def inventory(request):
    """Handle inventory management"""
    if request.method == 'POST':
        form = InventoryForm(request.POST)
        if form.is_valid():
            # Create new inventory item
            item = form.save(commit=False)
            item.location = request.user
            item.save()
            
            # Record the change
            InventoryChange.objects.create(
                item_name=item.name,
                action='added',
                quantity_before=None,
                quantity_after=item.quantity,
                location_name=request.user.location_name
            )
            
            messages.success(request, 'Item added successfully')
            return redirect('inventory')
    else:
        form = InventoryForm()
    
    # Get inventory items for the current user
    items = Inventory.objects.filter(location=request.user).order_by('-timestamp')
    
    return render(request, 'inventory.html', {'form': form, 'items': items})

@login_required
def edit_quantity(request, item_id):
    """Edit inventory item quantity"""
    item = get_object_or_404(Inventory, id=item_id, location=request.user)
    
    if request.method == 'POST':
        form = EditQuantityForm(request.POST)
        if form.is_valid():
            quantity_before = item.quantity
            new_quantity = form.cleaned_data['new_quantity']
            
            # Update the item
            item.quantity = new_quantity
            item.save()
            
            # Record the change
            InventoryChange.objects.create(
                item_name=item.name,
                action='edited',
                quantity_before=quantity_before,
                quantity_after=new_quantity,
                location_name=request.user.location_name
            )
            
            messages.success(request, 'Quantity updated successfully')
    
    return redirect('inventory')

@login_required
def delete_item(request, item_id):
    """Delete inventory item"""
    item = get_object_or_404(Inventory, id=item_id, location=request.user)
    
    if request.method == 'POST':
        item_name = item.name
        quantity_before = item.quantity
        
        # Delete the item
        item.delete()
        
        # Record the change
        InventoryChange.objects.create(
            item_name=item_name,
            action='deleted',
            quantity_before=quantity_before,
            quantity_after=None,
            location_name=request.user.location_name
        )
        
        messages.success(request, 'Item deleted successfully')
    
    return redirect('inventory')

@login_required
def inventory_changes(request):
    """Show inventory change history"""
    changes = InventoryChange.objects.filter(
        location_name=request.user.location_name
    ).order_by('-timestamp')
    
    return render(request, 'inventory_changes.html', {'changes': changes, 'user': request.user})

@login_required
def transfers(request):
    if request.method == 'POST':
        form = TransferForm(request.POST)
        if form.is_valid():
            item_name = form.cleaned_data['item_name']
            to_location_name = form.cleaned_data['to_location_name']
            quantity = form.cleaned_data['quantity']
            
            # Add additional validation
            if quantity <= 0:
                messages.error(request, 'Quantity must be greater than zero')
                return redirect('transfers')
                
            # Check if destination is same as source
            if to_location_name == request.user.location_name:
                messages.error(request, 'Cannot transfer to your own location')
                return redirect('transfers')
                
            try:
                # Use the utility function for transfers
                transfer_items(
                    request.user.location_name,
                    to_location_name,
                    {item_name: quantity}
                )
                messages.success(request, 'Transfer completed successfully')
            except Exception as e:
                messages.error(request, str(e))
    else:
        form = TransferForm()
    
    # Get transfers for the current user
    transfers_sent = Transfer.objects.filter(
        from_location=request.user.location_name
    ).order_by('-timestamp')
    
    transfers_received = Transfer.objects.filter(
        to_location=request.user.location_name
    ).order_by('-timestamp')
    
    return render(request, 'transfers.html', {
        'transfers_sent': transfers_sent,
        'transfers_received': transfers_received,
        'form': form,
        'user': request.user
    })

# Report generation views
@login_required
def generate_inventory_report(request):
    """Generate inventory report as CSV"""
    items = Inventory.objects.all().order_by('-timestamp')
    
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = f'attachment; filename="inventory_report_{datetime.now().strftime("%Y-%m-%d")}.csv"'
    
    writer = csv.writer(response, delimiter=';')
    writer.writerow(['Item Name', 'Quantity', 'Type', 'Timestamp'])
    
    for item in items:
        writer.writerow([
            item.name, 
            item.quantity, 
            item.type, 
            item.timestamp.strftime('%Y-%m-%d %H:%M:%S')
        ])
    
    return response

@login_required
def generate_inventory_changes_report(request):
    """Generate inventory changes report as CSV"""
    changes = InventoryChange.objects.all().order_by('-timestamp')
    
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = f'attachment; filename="inventory_changes_report_{datetime.now().strftime("%Y-%m-%d")}.csv"'
    
    writer = csv.writer(response, delimiter=';')
    writer.writerow(['Item Name', 'Action', 'Quantity Before', 'Quantity After', 'Location', 'Timestamp'])
    
    for change in changes:
        writer.writerow([
            change.item_name,
            change.action,
            change.quantity_before if change.quantity_before is not None else '-',
            change.quantity_after if change.quantity_after is not None else '-',
            change.location_name,
            change.timestamp.strftime('%Y-%m-%d %H:%M:%S')
        ])
    
    return response

@login_required
def generate_transfer_report(request):
    """Generate transfers report as CSV"""
    transfers = Transfer.objects.all().order_by('-timestamp')
    
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = f'attachment; filename="transfer_report_{datetime.now().strftime("%Y-%m-%d")}.csv"'
    
    writer = csv.writer(response, delimiter=';')
    writer.writerow(['Item', 'From Location', 'To Location', 'Quantity', 'Timestamp'])
    
    for transfer in transfers:
        writer.writerow([
            transfer.item,
            transfer.from_location,
            transfer.to_location,
            transfer.quantity,
            transfer.timestamp.strftime('%Y-%m-%d %H:%M:%S')
        ])
    
    return response

@login_required
def inventory_charts(request):
    """Display inventory visualization charts"""
    # Get chart data using utility functions
    from .utils import get_user_inventory_chart_data, get_other_users_inventory_chart_data
    
    # Get inventory data for charts
    user_inventory_data = get_user_inventory_chart_data(request.user)
    other_users_data = get_other_users_inventory_chart_data(request.user)
    
    context = {
        'user': request.user,
        'user_inventory_data': user_inventory_data,
        'other_users_data': other_users_data
    }
    
    return render(request, 'inventory_charts.html', context)

@login_required
def chat(request):
    """Display the chat interface with online users and chat output placeholder"""
    all_users = User.objects.exclude(id=request.user.id)
    sessions = Session.objects.filter(expire_date__gte=timezone.now())
    uid_list = []
    for session in sessions:
        try:
            data = session.get_decoded()
            uid = data.get('_auth_user_id')
            # Only add if the session is authenticated and the user exists
            if uid and User.objects.filter(id=uid).exists():
                uid_list.append(int(uid))
        except Exception:
            continue  # Skip corrupted or unauthenticated sessions
    online_users = User.objects.filter(id__in=uid_list).exclude(id=request.user.id)

    # Fetch last 50 team messages and last 50 private messages involving the user
    team_messages = ChatMessage.objects.filter(is_team_message=True).order_by('-timestamp')[:50]
    private_messages = ChatMessage.objects.filter(
        is_team_message=False
    ).filter(
        models.Q(sender=request.user) | models.Q(recipient=request.user)
    ).order_by('-timestamp')[:50]
    # Combine and sort by timestamp descending
    chat_messages = sorted(
        list(team_messages) + list(private_messages),
        key=lambda m: m.timestamp,
        reverse=True
    )[:50]
    chat_messages = reversed(chat_messages)  # Show oldest first

    context = {
        'user': request.user,
        'all_users': all_users,
        'online_users': online_users,
        'chat_messages': chat_messages,
    }
    return render(request, 'chat.html', context)

@login_required
def damaged_items(request):
    """Registrer og vis ødelagte produkter"""
    if request.method == 'POST':
        name = request.POST.get('name')
        quantity = request.POST.get('quantity')
        location = request.user.location_name
        if name and quantity:
            DamagedItem.objects.create(
                name=name,
                quantity=quantity,
                location=location,
                user=request.user
            )
            messages.success(request, 'Ødelagt produkt registreret')
            return redirect('damaged_items')
    items = DamagedItem.objects.filter(user=request.user).order_by('-id')
    return render(request, 'damaged.html', {'items': items})

@login_required
def opened_items(request):
    """Registrer og vis anbrudte produkter"""
    if request.method == 'POST':
        name = request.POST.get('name')
        quantity = request.POST.get('quantity')
        location = request.user.location_name
        if name and quantity:
            OpenedItem.objects.create(
                name=name,
                quantity=quantity,
                location=location,
                user=request.user
            )
            messages.success(request, 'Anbrud registreret')
            return redirect('opened_items')
    items = OpenedItem.objects.filter(user=request.user).order_by('-id')
    return render(request, 'opened.html', {'items': items})

@login_required
def export_damaged_csv(request):
    """Eksporter ødelagte produkter som CSV"""
    items = DamagedItem.objects.filter(user=request.user).order_by('-id')
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = f'attachment; filename="damaged_{datetime.now().strftime("%Y-%m-%d")}.csv"'
    writer = csv.writer(response)
    writer.writerow(['Navn', 'Antal', 'Lokation'])
    for item in items:
        writer.writerow([item.name, item.quantity, item.location])
    return response

@login_required
def export_opened_csv(request):
    """Eksporter anbrud som CSV"""
    items = OpenedItem.objects.filter(user=request.user).order_by('-id')
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = f'attachment; filename="opened_{datetime.now().strftime("%Y-%m-%d")}.csv"'
    writer = csv.writer(response)
    writer.writerow(['Navn', 'Antal', 'Lokation'])
    for item in items:
        writer.writerow([item.name, item.quantity, item.location])
    return response

# --- NOTE: If you see "Session data corrupted" warnings ---
# - Make sure your SECRET_KEY in settings.py is not changing between server restarts.
# - Clear old sessions: python manage.py clearsessions
# - Clear browser cookies for your site.
