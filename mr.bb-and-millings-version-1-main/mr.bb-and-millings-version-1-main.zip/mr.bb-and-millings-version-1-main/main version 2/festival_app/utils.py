import logging
from django.conf import settings
from django.db import transaction
from django.db.models import Sum
from django.shortcuts import get_object_or_404
from django.utils import timezone

# Import models from their correct modular app locations
from users_app.models import User
from inventory_app.models import Inventory, InventoryChange
from transfers_app.models import Transfer

def setup_logging():
    """Set up logging for the application."""
    logging.basicConfig(
        level=getattr(logging, settings.LOGGING_LEVEL, 'INFO'),
        format=settings.LOG_FORMAT if hasattr(settings, 'LOG_FORMAT') else '%(asctime)s [%(levelname)s] %(message)s',
    )
    logging.info("Logging initialized.")

def location_exists(location_name):
    """Check if a location exists by name"""
    from users_app.models import User
    return User.objects.filter(location_name=location_name).exists()

def transfer_items(source_location, destination_location, items_dict):
    """
    Transfer items from one location to another
    
    Args:
        source_location (str): Source location name
        destination_location (str): Destination location name
        items_dict (dict): Dictionary mapping item names to quantities
    
    Returns:
        bool: True if successful
        
    Raises:
        ValueError: If items don't exist or quantities are insufficient
    """
    
    # Validate source and destination
    if source_location == destination_location:
        raise ValueError("Cannot transfer to the same location")
    
    # Get users
    try:
        source_user = User.objects.get(location_name=source_location)
    except User.DoesNotExist:
        raise ValueError(f"Source location {source_location} not found")
        
    try:
        dest_user = User.objects.get(location_name=destination_location)
    except User.DoesNotExist:
        raise ValueError(f"Destination location {destination_location} not found")
    
    # Process each item
    with transaction.atomic():
        for item_name, quantity in items_dict.items():
            if quantity <= 0:
                raise ValueError(f"Transfer quantity must be positive for {item_name}")
            
            # Check if source has the item
            try:
                source_item = Inventory.objects.get(
                    name=item_name,
                    location=source_user
                )
            except Inventory.DoesNotExist:
                raise ValueError(f"Item {item_name} not found in {source_location}")
                
            # Check if there's enough quantity
            if source_item.quantity < quantity:
                raise ValueError(f"Not enough {item_name} in inventory to transfer.")
            
            # Update source item
            source_item.quantity -= quantity
            source_item.save()
            
            # Record source change
            InventoryChange.objects.create(
                item_name=item_name,
                action='edited',
                quantity_before=source_item.quantity + quantity,
                quantity_after=source_item.quantity,
                location_name=source_location
            )
            
            # Check if destination already has this item
            dest_item, created = Inventory.objects.get_or_create(
                name=item_name,
                location=dest_user,
                defaults={
                    'quantity': 0,
                    'type': source_item.type
                }
            )
            
            # Update destination quantity
            old_quantity = dest_item.quantity
            dest_item.quantity += quantity
            dest_item.save()
            
            # Record destination change
            InventoryChange.objects.create(
                item_name=item_name,
                action='edited',
                quantity_before=old_quantity,
                quantity_after=dest_item.quantity,
                location_name=destination_location
            )
            
            # Create transfer record
            Transfer.objects.create(
                item=item_name,
                from_location=source_location,
                to_location=destination_location,
                quantity=quantity
            )
    
    return True

def record_inventory_change(item_name, action, quantity_before, quantity_after, location_name):
    """Create inventory change record compatible with both systems"""
    from inventory_app.models import InventoryChange
    
    InventoryChange.objects.create(
        item_name=item_name,
        action=action,
        quantity_before=quantity_before,
        quantity_after=quantity_after,
        location_name=location_name
    )

def get_user_inventory_chart_data(user):
    """
    Get the current user's inventory data for a pie chart.
    Returns data grouped by item type.
    """
    from inventory_app.models import Inventory
    
    # Get inventory items for the user grouped by type
    type_data = Inventory.objects.filter(location=user) \
                .values('type') \
                .annotate(quantity=Sum('quantity')) \
                .order_by('type')
    
    # Ensure quantity > 0 to avoid empty segments
    type_data = [item for item in type_data if item['quantity'] > 0]
    
    return list(type_data)

def get_other_users_inventory_chart_data(current_user):
    """
    Get inventory data from other users for a bar chart.
    Returns data categorized by item type for each location.
    """
    from users_app.models import User
    from inventory_app.models import Inventory
    from django.conf import settings
    
    # Get all users except current user
    other_users = User.objects.exclude(id=current_user.id).values('id', 'location_name')
    
    # Initialize result structure
    result = {
        'locations': [],
        'datasets': []
    }
    
    # Get all unique item types from settings
    item_types = settings.ITEM_TYPES
    
    # Create a dataset for each item type
    colors = ['#4A7BBA', '#FF6384', '#36A2EB', '#FFCE56', '#4BC0C0', '#9966FF', '#FF9F40', '#47A847']
    
    # Create a list of location names to use as labels on the chart
    location_names = [user['location_name'] for user in other_users]
    result['locations'] = location_names
    
    # For each item type, create a dataset containing quantities for each location
    for i, item_type in enumerate(item_types):
        dataset = {
            'label': item_type,
            'backgroundColor': colors[i % len(colors)],
            'data': []
        }
        
        # For each location, get the quantity of this item type
        for user in other_users:
            quantity = Inventory.objects.filter(
                location_id=user['id'],
                type=item_type
            ).aggregate(Sum('quantity'))['quantity__sum'] or 0
            
            dataset['data'].append(quantity)
        
        # Only add the dataset if there's at least one non-zero value
        if any(qty > 0 for qty in dataset['data']):
            result['datasets'].append(dataset)
    
    return result
