import logging
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.contrib import messages
from django.db.models import Q
from django.utils import timezone
from django.contrib.sessions.models import Session
from django.conf import settings
from users_app.models import User
from chat_app.models import ChatMessage

logger = logging.getLogger(__name__)

@login_required
def chat(request):
    """Display the chat interface with safer session handling"""
    try:
        # Simple queries with minimal potential for session storage issues
        all_users = User.objects.exclude(id=request.user.id).only('id', 'username', 'location_name')
        
        # Get active sessions more carefully
        try:
            # Get online users by checking active sessions
            online_users = []
            sessions = Session.objects.filter(expire_date__gte=timezone.now())
            uid_list = []
            
            for session in sessions:
                try:
                    data = session.get_decoded()
                    uid = data.get('_auth_user_id')
                    if uid and uid != str(request.user.id):
                        uid_list.append(int(uid))
                except Exception as e:
                    # Skip problematic sessions, don't crash
                    logger.warning(f"Skipping corrupted session: {e}")
                    continue
            
            if uid_list:
                online_users = User.objects.filter(id__in=uid_list).only('id', 'username', 'location_name')
        except Exception as e:
            # If online user detection fails, continue without it
            logger.error(f"Error getting online users: {e}")
            online_users = []
        
        # Get chat messages with safer queries
        try:
            team_messages = ChatMessage.objects.filter(
                is_team_message=True
            ).order_by('-timestamp')[:30]
            
            private_messages = ChatMessage.objects.filter(
                is_team_message=False
            ).filter(
                Q(sender=request.user) | Q(recipient=request.user)
            ).order_by('-timestamp')[:20]
            
            # Combine safely
            all_messages = list(team_messages) + list(private_messages)
            all_messages.sort(key=lambda m: m.timestamp, reverse=True)
            # Limit to avoid large sessions
            chat_messages = reversed(all_messages[:50])
        except Exception as e:
            logger.error(f"Error loading chat messages: {e}")
            chat_messages = []
            messages.warning(request, "Unable to load chat history. Please try logging out and back in.")
        
        return render(request, 'chat.html', {
            'all_users': all_users,
            'online_users': online_users,
            'chat_messages': chat_messages,
        })
        
    except Exception as e:
        logger.error(f"Critical error in chat view: {e}")
        messages.error(request, "Unable to load chat. Please try logging out and back in.")
        return redirect('dashboard')
