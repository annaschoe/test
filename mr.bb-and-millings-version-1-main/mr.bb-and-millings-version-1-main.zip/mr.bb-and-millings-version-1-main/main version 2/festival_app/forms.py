from django import forms
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.conf import settings

# Import models from their correct modular app locations
from users_app.models import User
from inventory_app.models import Inventory
from transfers_app.models import Transfer

class CustomUserCreationForm(UserCreationForm):
    """Form for creating new users"""
    location_name = forms.CharField(max_length=255, required=True, 
                                   help_text="Enter the name of your festival location")

    class Meta:
        model = User
        fields = ('username', 'location_name', 'password1', 'password2')

class CustomAuthenticationForm(AuthenticationForm):
    """Form for authenticating users"""
    class Meta:
        model = User
        fields = ('username', 'password')

class InventoryForm(forms.ModelForm):
    """Form for adding/editing inventory items"""
    type = forms.ChoiceField(choices=[(t, t) for t in settings.ITEM_TYPES])
    
    class Meta:
        model = Inventory
        fields = ('name', 'quantity', 'type')

class TransferForm(forms.Form):
    """Form for creating transfers"""
    item_name = forms.CharField(max_length=255, required=True)
    to_location_name = forms.CharField(max_length=255, required=True)
    quantity = forms.IntegerField(min_value=1, required=True)

class EditQuantityForm(forms.Form):
    """Form for editing inventory quantity"""
    new_quantity = forms.IntegerField(min_value=0)
