from django.urls import path
from . import views, chat_views, api

urlpatterns = [
    # Authentication
    path('login/', views.login_view, name='login'),
    path('register/', views.register_view, name='register'),
    path('logout/', views.logout_view, name='logout'),
    
    # Main routes
    path('', views.index, name='index'),
    path('dashboard/', views.dashboard, name='dashboard'),
    
    # Inventory
    path('inventory/', views.inventory, name='inventory'),
    path('inventory/changes/', views.inventory_changes, name='inventory_changes'),
    path('inventory/edit/<int:item_id>/', views.edit_quantity, name='edit_quantity'),
    path('inventory/delete/<int:item_id>/', views.delete_item, name='delete_item'),
    path('inventory/charts/', views.inventory_charts, name='inventory_charts'),
    
    # Transfers
    path('transfers/', views.transfers, name='transfers'),
    path('transfers/generate-report/', views.generate_transfer_report, name='generate_transfer_report'),
    
    # Reports
    path('reports/inventory/', views.generate_inventory_report, name='generate_inventory_report'),
    path('reports/changes/', views.generate_inventory_changes_report, name='generate_inventory_changes_report'),
    
    # Chat - use the new, more resilient view
    path('chat/', chat_views.chat, name='chat'),
    
    # API endpoints
    path('api/upload-chat-file/', api.upload_chat_file, name='upload_chat_file'),
]
