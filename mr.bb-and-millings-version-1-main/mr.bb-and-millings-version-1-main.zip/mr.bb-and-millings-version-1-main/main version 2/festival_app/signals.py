"""
Signal handlers for the festival_app application.
During the transition to modular apps, this file provides compatibility
with existing models and will eventually be phased out.
"""
from django.db.models.signals import post_save, post_delete, pre_save
from django.dispatch import receiver
from django.utils import timezone
import logging

# Import models from their correct modular app locations
from users_app.models import User
from inventory_app.models import Inventory, InventoryChange
from transfers_app.models import Transfer
from chat_app.models import ChatMessage

logger = logging.getLogger(__name__)

@receiver(post_save, sender=User)
def user_created_or_updated(sender, instance, created, **kwargs):
    """Log when a user is created or updated"""
    if created:
        logger.info(f"New user created: {instance.username} ({instance.location_name})")
    else:
        logger.info(f"User updated: {instance.username} ({instance.location_name})")

@receiver(post_save, sender=Inventory)
def inventory_save_handler(sender, instance, created, **kwargs):
    """Log inventory changes and create automatic change records"""
    if created:
        logger.info(f"New inventory item added: {instance.name} at {instance.location.location_name}")
    else:
        logger.info(f"Inventory updated: {instance.name} at {instance.location.location_name}")

@receiver(post_delete, sender=Inventory)
def inventory_delete_handler(sender, instance, **kwargs):
    """Log when inventory items are deleted"""
    logger.info(f"Inventory deleted: {instance.name} from {instance.location.location_name}")

@receiver(post_save, sender=Transfer)
def transfer_save_handler(sender, instance, created, **kwargs):
    """Log transfer creation"""
    if created:
        logger.info(f"Transfer created: {instance.quantity} {instance.item} from {instance.from_location} to {instance.to_location}")

@receiver(post_save, sender=ChatMessage)
def chat_message_handler(sender, instance, created, **kwargs):
    """Handle chat message events"""
    if created:
        if instance.is_team_message:
            logger.info(f"Team message sent by {instance.sender.username}")
        elif instance.recipient:
            logger.info(f"Private message sent by {instance.sender.username} to {instance.recipient.username}")
