from django.apps import AppConfig

class UsersAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'users_app'
    verbose_name = 'User Management'
    
    def ready(self):
        """
        Initialize users app when Django starts.
        """
        # Import signal handlers
        try:
            import users_app.signals
        except ImportError:
            pass
