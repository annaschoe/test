from django.db import models
from django.contrib.auth.models import AbstractUser
from django.utils import timezone

class User(AbstractUser):
    """User model with location information"""
    location_name = models.CharField(max_length=255, blank=True)
    last_activity = models.DateTimeField(default=timezone.now)
    
    # Additional fields for improved user management
    phone_number = models.CharField(max_length=20, blank=True)
    is_location_manager = models.BooleanField(default=False)
    notes = models.TextField(blank=True)
    
    # Fix the reverse accessor clash with festival_app.User
    groups = models.ManyToManyField(
        'auth.Group',
        verbose_name='groups',
        blank=True,
        help_text='The groups this user belongs to. A user will get all permissions granted to each of their groups.',
        related_name='users_app_user_set',
        related_query_name='users_app_user'
    )
    
    user_permissions = models.ManyToManyField(
        'auth.Permission',
        verbose_name='user permissions',
        blank=True,
        help_text='Specific permissions for this user.',
        related_name='users_app_user_set',
        related_query_name='users_app_user'
    )
    
    def __str__(self):
        return f"{self.username} ({self.location_name})"
        
    class Meta:
        indexes = [
            models.Index(fields=['location_name']),
            models.Index(fields=['is_location_manager']),
        ]
        
    def update_last_activity(self):
        """Update the user's last activity timestamp"""
        self.last_activity = timezone.now()
        self.save(update_fields=['last_activity'])
