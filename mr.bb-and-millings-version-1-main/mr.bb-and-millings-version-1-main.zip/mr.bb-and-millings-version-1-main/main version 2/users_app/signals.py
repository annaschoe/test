"""
Signal handlers for the users_app.
"""
from django.db.models.signals import post_save, post_delete
from django.dispatch import receiver
from django.utils import timezone
import logging

from users_app.models import User

logger = logging.getLogger('users')

@receiver(post_save, sender=User)
def user_created_or_updated(sender, instance, created, **kwargs):
    """Log when a user is created or updated"""
    if created:
        logger.info(f"New user created: {instance.username} ({instance.location_name})")
    else:
        # Only log non-trivial updates (excluding last activity updates)
        if 'update_fields' not in kwargs or (kwargs['update_fields'] and 'last_activity' not in kwargs['update_fields']):
            logger.info(f"User updated: {instance.username} ({instance.location_name})")

@receiver(post_delete, sender=User)
def user_deleted(sender, instance, **kwargs):
    """Log when a user is deleted"""
    logger.info(f"User deleted: {instance.username} ({instance.location_name})")
