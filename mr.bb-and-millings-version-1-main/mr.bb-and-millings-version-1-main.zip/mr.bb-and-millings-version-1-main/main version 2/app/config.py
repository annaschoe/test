import os
import secrets
from datetime import timedelta

class Config:
    """Application configuration settings."""
    BASE_DIR = os.path.abspath(os.path.dirname(__file__))
    DATABASE_PATH = os.path.join(BASE_DIR, 'inventory.db')
    TEMP_DIR = os.path.join(BASE_DIR, 'temp')
    LOG_DIR = os.path.join(BASE_DIR, 'logs')

    # Security
    SECRET_KEY = os.environ.get('SECRET_KEY', secrets.token_hex(16))
    PERMANENT_SESSION_LIFETIME = timedelta(days=7)
    SESSION_COOKIE_SECURE = os.environ.get('PRODUCTION', 'False') == 'True'
    SESSION_COOKIE_HTTPONLY = True
    SESSION_COOKIE_SAMESITE = 'Lax'

    # Database settings
    SQLITE_TIMEOUT = 30
    DATABASE_PERMISSIONS = 0o600  # Owner read/write only

    # Application settings
    ITEM_TYPES = ["Glass", "Plastic", "Metal", "Other"]

    # Password requirements
    PASSWORD_MIN_LENGTH = 8
    PASSWORD_REQUIRE_SPECIAL = True

    # Default admin user settings
    DEFAULT_ADMIN = {
        'username': 'admin',
        'password': os.environ.get('ADMIN_PASSWORD', 'admin_password'),
        'location': 'default_location'
    }
    
    # Rate limiting
    RATELIMIT_DEFAULT = ["200 per day", "50 per hour"]
    RATELIMIT_STORAGE_URI = "memory://"
    
    # CSRF protection
    WTF_CSRF_TIME_LIMIT = 3600  # 1 hour
    
    # Logging configuration
    LOG_LEVEL = os.environ.get('LOG_LEVEL', 'INFO')
    LOG_FORMAT = '%(asctime)s [%(levelname)s] %(message)s'
    LOG_MAX_BYTES = 1024 * 1024  # 1MB
    LOG_BACKUP_COUNT = 5
