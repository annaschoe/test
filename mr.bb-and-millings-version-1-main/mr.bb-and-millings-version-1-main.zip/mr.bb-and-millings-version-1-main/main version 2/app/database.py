import sqlite3
import logging
from contextlib import contextmanager
from config import Config


@contextmanager
def get_db():
    """Database connection context manager."""
    conn = sqlite3.connect(Config.DATABASE_PATH)
    conn.row_factory = sqlite3.Row
    try:
        yield conn
    finally:
        conn.close()


def init_db():
    """Initialize the database and create tables if they don't exist."""
    try:
        with get_db() as conn:
            cursor = conn.cursor()
            cursor.executescript('''
                CREATE TABLE IF NOT EXISTS users (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    username TEXT UNIQUE NOT NULL,
                    password TEXT NOT NULL,
                    location_name TEXT NOT NULL,
                    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                );
                
                CREATE TABLE IF NOT EXISTS inventory (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    name TEXT NOT NULL,
                    quantity INTEGER NOT NULL CHECK (quantity >= 0),
                    type TEXT NOT NULL,
                    location_id INTEGER NOT NULL,
                    location_name TEXT NOT NULL,  -- Tilføjet felt
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    FOREIGN KEY (location_id) REFERENCES users(id) ON DELETE CASCADE
                );

                CREATE TABLE IF NOT EXISTS transfers (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    item TEXT NOT NULL,
                    from_location TEXT NOT NULL,
                    to_location TEXT NOT NULL,
                    quantity INTEGER NOT NULL CHECK (quantity > 0),
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                );

                CREATE TABLE IF NOT EXISTS inventory_changes (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    item_name TEXT NOT NULL,
                    action TEXT NOT NULL CHECK (action IN ('added', 'edited', 'deleted')), -- Sikret mod ukendte værdier
                    quantity_before INTEGER,
                    quantity_after INTEGER,
                    location_name TEXT NOT NULL,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
                );
            ''')
            conn.commit()
            logging.info(" Database initialized successfully.")
    except sqlite3.Error as e:
        logging.error(f" Error initializing database: {e}", exc_info=True)


def record_inventory_change(item_name, action, quantity_before, quantity_after, location_name):
    """Registrer ændringer i inventar i databasen."""
    try:
        with get_db() as conn:
            cursor = conn.cursor()
            cursor.execute("""
                INSERT INTO inventory_changes (item_name, action, quantity_before, quantity_after, location_name)
                VALUES (?, ?, ?, ?, ?)
            """, (item_name, action, quantity_before, quantity_after, location_name))
            conn.commit()
    except sqlite3.Error as e:
        logging.error(f" Error recording inventory change: {e}", exc_info=True)
