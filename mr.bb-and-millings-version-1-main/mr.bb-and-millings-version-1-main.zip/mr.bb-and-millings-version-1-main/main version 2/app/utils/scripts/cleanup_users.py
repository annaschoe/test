import sqlite3
import logging
from app.database import get_db

def remove_users_except_admin():
    """Remove all users except for ID 1 (admin)."""
    try:
        with get_db() as conn:
            cursor = conn.cursor()
            
            # Find all users except admin
            cursor.execute("SELECT id FROM users WHERE id != 1")
            user_ids = [row['id'] for row in cursor.fetchall()]
            
            if not user_ids:
                logging.info("No additional users to remove.")
                return
            
            logging.info(f"Preparing to remove {len(user_ids)} users...")
            
            # Delete related inventory and transfers
            cursor.execute("DELETE FROM transfers WHERE from_location_id IN ({}) OR to_location_id IN ({})".format(
                ','.join(['?'] * len(user_ids)), ','.join(['?'] * len(user_ids))
            ), user_ids * 2)
            
            cursor.execute("DELETE FROM inventory WHERE location_id IN ({})".format(
                ','.join(['?'] * len(user_ids))
            ), user_ids)
            
            # Finally remove users
            cursor.execute("DELETE FROM users WHERE id != 1")
            conn.commit()
            logging.info("Successfully removed non-admin users.")
    except Exception as e:
        logging.error(f"Error removing users: {e}")

if __name__ == "__main__":
    logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
    logging.info("Starting cleanup script...")
    remove_users_except_admin()
    logging.info("Cleanup completed. Only admin user (ID 1) remains.")