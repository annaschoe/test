import logging

def setup_logging(app):
    """Set up logging for the application."""
    logging.basicConfig(
        level=app.config.get("LOG_LEVEL", "INFO"),
        format=app.config.get("LOG_FORMAT", "%(asctime)s [%(levelname)s] %(message)s"),
    )
    logging.info("Logging initialized.")
