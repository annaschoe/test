import pytest
from unittest.mock import patch, MagicMock
from core_app.utils.decorators import timer_decorator, log_action, superuser_required
from core_app.utils.logging_utils import get_logger
from django.http import HttpResponseForbidden

@pytest.mark.django_db
class TestDecorators:
    
    @patch('time.time')
    @patch('logging.Logger.info')
    def test_timer_decorator(self, mock_logger_info, mock_time):
        # Setup
        mock_time.side_effect = [100, 105]  # Start time, end time
        
        # Apply decorator to test function
        @timer_decorator
        def sample_function():
            return "Done"
        
        # Execute
        result = sample_function()
        
        # Assert
        assert result == "Done"
        mock_logger_info.assert_called_once_with(
            "Function sample_function took 5.0000 seconds to execute"
        )
    
    @patch('logging.Logger.info')
    def test_log_action(self, mock_logger_info):
        # Setup mock request
        mock_request = MagicMock()
        mock_request.user.is_authenticated = True
        mock_request.user.username = "test_user"
        mock_request.user.location_name = "Test Location"
        
        # Apply decorator to test function
        @log_action("inventory_update")
        def sample_view(request):
            return "View result"
        
        # Execute
        result = sample_view(mock_request)
        
        # Assert
        assert result == "View result"
        mock_logger_info.assert_called_once_with(
            "INVENTORY_UPDATE: User test_user (Test Location) performed sample_view"
        )
    
    def test_superuser_required_with_superuser(self):
        # Setup mock request with superuser
        mock_request = MagicMock()
        mock_request.user.is_superuser = True
        
        # Apply decorator to test function
        @superuser_required
        def admin_view(request):
            return "Admin view"
        
        # Execute
        result = admin_view(mock_request)
        
        # Assert
        assert result == "Admin view"
    
    def test_superuser_required_with_regular_user(self):
        # Setup mock request with non-superuser
        mock_request = MagicMock()
        mock_request.user.is_superuser = False
        mock_request.user.username = "regular_user"
        
        # Apply decorator to test function
        @superuser_required
        def admin_view(request):
            return "Admin view"
        
        # Execute
        result = admin_view(mock_request)
        
        # Assert
        assert isinstance(result, HttpResponseForbidden)

class TestLoggingUtils:
    
    @patch('logging.Logger')
    def test_get_logger(self, mock_logger_class):
        # Setup
        mock_logger = MagicMock()
        mock_logger_class.return_value = mock_logger
        
        # Execute
        with patch('logging.getLogger', return_value=mock_logger) as mock_get_logger:
            logger = get_logger("test_module")
            
            # Assert
            mock_get_logger.assert_called_once_with("test_module")
            assert logger == mock_logger
