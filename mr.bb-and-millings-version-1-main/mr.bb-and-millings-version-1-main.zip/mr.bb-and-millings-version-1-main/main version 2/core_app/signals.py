"""
Signal handlers for the core_app.
This handles application-wide signals like user login/logout events.
"""
from django.db.models.signals import post_migrate
from django.dispatch import receiver
from django.contrib.auth.signals import user_logged_in, user_logged_out
import logging

logger = logging.getLogger('core')

@receiver(user_logged_in)
def user_logged_in_handler(sender, request, user, **kwargs):
    """Log when users log in"""
    logger.info(f"User logged in: {user.username} ({user.location_name}) from {request.META.get('REMOTE_ADDR')}")
    
    # Update user's last activity
    if hasattr(user, 'update_last_activity'):
        user.update_last_activity()

@receiver(user_logged_out)
def user_logged_out_handler(sender, request, user, **kwargs):
    """Log when users log out"""
    if user:
        logger.info(f"User logged out: {user.username} ({user.location_name})")

@receiver(post_migrate)
def post_migrate_handler(sender, **kwargs):
    """
    Run setup tasks after migrations are applied.
    This is useful for ensuring initial data exists.
    """
    if sender.name == 'core_app':
        logger.info("Running post-migration setup for core_app")
        # You could add initial setup code here
