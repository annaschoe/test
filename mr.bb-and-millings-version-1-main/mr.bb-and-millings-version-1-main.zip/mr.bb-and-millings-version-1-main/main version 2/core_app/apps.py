from django.apps import AppConfig

class CoreAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'core_app'
    verbose_name = 'Core Application'
    
    def ready(self):
        """
        Initialize the application when Django starts.
        """
        # Import signal handlers and other initialization 
        try:
            import core_app.signals
        except ImportError:
            pass

        # Initialize logging
        from core_app.utils.logging_utils import setup_logging
        setup_logging()
