import logging
import os
from django.conf import settings

def setup_logging():
    """
    Set up logging for the application with more advanced configuration.
    """
    log_level = getattr(settings, 'LOGGING_LEVEL', 'INFO')
    log_format = getattr(settings, 'LOG_FORMAT', 
        '%(asctime)s [%(levelname)s] %(name)s: %(message)s')
    
    logging.basicConfig(
        level=getattr(logging, log_level),
        format=log_format
    )
    
    # Create custom loggers for different components
    loggers = ['inventory', 'transfers', 'users', 'chat', 'core']
    for logger_name in loggers:
        logger = logging.getLogger(logger_name)
        logger.setLevel(getattr(logging, log_level))
        
    # Log that initialization is complete
    logging.info("Application logging initialized")

def get_logger(name):
    """
    Get a properly configured logger for a specific module.
    
    Args:
        name (str): Name of the logger, typically __name__
        
    Returns:
        logging.Logger: Configured logger instance
    """
    return logging.getLogger(name)
