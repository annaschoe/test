import functools
import time
import logging
from django.http import HttpResponseForbidden
from django.conf import settings

logger = logging.getLogger(__name__)

def timer_decorator(func):
    """
    Decorator to time the execution of a function.
    
    Usage:
        @timer_decorator
        def my_function():
            pass
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        start_time = time.time()
        result = func(*args, **kwargs)
        elapsed_time = time.time() - start_time
        logger.info(f"Function {func.__name__} took {elapsed_time:.4f} seconds to execute")
        return result
    return wrapper

def log_action(action_type):
    """
    Decorator to log actions performed by users.
    
    Usage:
        @log_action('inventory_update')
        def update_inventory(request, ...):
            pass
    """
    def decorator(func):
        @functools.wraps(func)
        def wrapper(request, *args, **kwargs):
            result = func(request, *args, **kwargs)
            if request.user.is_authenticated:
                logger.info(f"{action_type.upper()}: User {request.user.username} ({request.user.location_name}) performed {func.__name__}")
            return result
        return wrapper
    return decorator

def superuser_required(func):
    """
    Decorator to restrict view access to superusers only.
    Similar to Django's staff_member_required but stricter.
    
    Usage:
        @superuser_required
        def admin_only_view(request, ...):
            pass
    """
    @functools.wraps(func)
    def wrapper(request, *args, **kwargs):
        if not request.user.is_superuser:
            logger.warning(f"Access denied: User {request.user.username} attempted to access superuser function {func.__name__}")
            return HttpResponseForbidden("You do not have permission to access this page")
        return func(request, *args, **kwargs)
    return wrapper

def feature_flag(flag_name):
    """
    Decorator to enable/disable features based on settings.
    
    Usage:
        @feature_flag('ENABLE_ADVANCED_REPORTING')
        def advanced_reports(request, ...):
            pass
    """
    def decorator(func):
        @functools.wraps(func)
        def wrapper(*args, **kwargs):
            if getattr(settings, flag_name, False):
                return func(*args, **kwargs)
            logger.info(f"Feature {flag_name} is disabled, skipping {func.__name__}")
            return HttpResponseForbidden("This feature is currently disabled")
        return wrapper
    return decorator
